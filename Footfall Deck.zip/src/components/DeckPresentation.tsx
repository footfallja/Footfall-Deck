import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Circle } from 'lucide-react';
import { Slide01Cover } from './slides/Slide01Cover';
import { Slide02Breakpoint } from './slides/Slide02Breakpoint';
import { Slide03WhyExecutionFails } from './slides/Slide03WhyExecutionFails';
import { Slide04JamaicanReality } from './slides/Slide04JamaicanReality';
import { Slide05TheGap } from './slides/Slide05TheGap';
import { Slide06FootfallRole } from './slides/Slide06FootfallRole';
import { Slide07HowFootfallExecutes } from './slides/Slide07HowFootfallExecutes';
import { Slide08CaseStudyCarnival } from './slides/Slide08CaseStudyCarnival';
import { Slide09CaseStudySampling } from './slides/Slide09CaseStudySampling';
import { Slide10CaseStudySumfest } from './slides/Slide10CaseStudySumfest';
import { Slide11WhatCasesProve } from './slides/Slide11WhatCasesProve';
import { Slide12BMaaSHero } from './slides/Slide12BMaaSHero';
import { Slide13BMaaSTiers } from './slides/Slide13BMaaSTiers';
import { Slide14WhyFootfall } from './slides/Slide14WhyFootfall';
import { Slide15Closing } from './slides/Slide15Closing';

const slides = [
  { id: 1, component: Slide01Cover, title: 'Cover' },
  { id: 2, component: Slide02Breakpoint, title: 'The Breakpoint' },
  { id: 3, component: Slide03WhyExecutionFails, title: 'Why Execution Fails' },
  { id: 4, component: Slide04JamaicanReality, title: 'Jamaican Retail Reality' },
  { id: 5, component: Slide05TheGap, title: 'The Gap' },
  { id: 6, component: Slide06FootfallRole, title: 'Our Role' },
  { id: 7, component: Slide07HowFootfallExecutes, title: 'How We Execute' },
  { id: 8, component: Slide08CaseStudyCarnival, title: 'Case: Carnival' },
  { id: 9, component: Slide09CaseStudySampling, title: 'Case: Sampling' },
  { id: 10, component: Slide10CaseStudySumfest, title: 'Case: Sumfest' },
  { id: 11, component: Slide11WhatCasesProve, title: 'What This Proves' },
  { id: 12, component: Slide12BMaaSHero, title: 'BMaaS' },
  { id: 13, component: Slide13BMaaSTiers, title: 'Pricing Tiers' },
  { id: 14, component: Slide14WhyFootfall, title: 'Why Footfall' },
  { id: 15, component: Slide15Closing, title: 'Get in Touch' },
];

export function DeckPresentation() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goToSlide = (index: number) => {
    if (index >= 0 && index < slides.length && index !== currentSlide) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(index);
        setTimeout(() => setIsTransitioning(false), 50);
      }, 200);
    }
  };

  const goToNext = () => goToSlide(currentSlide + 1);
  const goToPrevious = () => goToSlide(currentSlide - 1);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') goToNext();
      if (e.key === 'ArrowLeft') goToPrevious();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  const CurrentSlideComponent = slides[currentSlide].component;

  return (
    <div className="min-h-screen bg-[#FAFAFA] flex flex-col">
      {/* Minimal Top Bar */}
      <div className="bg-white border-b border-[#E5E5E5] px-8 py-5 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-2 h-8 bg-[#6EC1E4] rounded-full"></div>
          <span className="font-['Outfit'] text-lg tracking-tight text-[#2F2F2F]">
            FOOTFALL LIMITED
          </span>
        </div>
        <div className="flex items-center gap-6 text-sm text-[#4A5C6A] font-['Inter']">
          <span className="hidden md:inline">{slides[currentSlide].title}</span>
          <span className="bg-[#F5F5F5] px-3 py-1 rounded-full">
            {String(currentSlide + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
          </span>
        </div>
      </div>

      {/* Main Slide Container */}
      <div className="flex-1 relative overflow-hidden bg-white">
        <div 
          className={`w-full h-full transition-opacity duration-200 ${
            isTransitioning ? 'opacity-0' : 'opacity-100'
          }`}
        >
          <CurrentSlideComponent />
        </div>
      </div>

      {/* Modern Bottom Navigation */}
      <div className="bg-white border-t border-[#E5E5E5] px-8 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
          {/* Previous Button */}
          <button
            onClick={goToPrevious}
            disabled={currentSlide === 0}
            className={`group flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all font-['Inter'] text-sm ${
              currentSlide === 0
                ? 'opacity-30 cursor-not-allowed text-[#4A5C6A]'
                : 'hover:bg-[#F5F5F5] text-[#2F2F2F]'
            }`}
          >
            <ChevronLeft className={`w-4 h-4 transition-transform ${
              currentSlide !== 0 ? 'group-hover:-translate-x-0.5' : ''
            }`} />
            <span className="hidden sm:inline">Previous</span>
          </button>

          {/* Dot Indicators */}
          <div className="flex-1 flex items-center justify-center gap-2 overflow-x-auto py-2 px-4">
            {slides.map((slide, index) => (
              <button
                key={slide.id}
                onClick={() => goToSlide(index)}
                className="group relative flex items-center justify-center"
                aria-label={`Go to slide ${index + 1}`}
              >
                {index === currentSlide ? (
                  <div className="flex items-center gap-2 bg-[#6EC1E4] px-4 py-1.5 rounded-full transition-all">
                    <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                    <span className="text-white font-['Inter'] text-xs">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                  </div>
                ) : (
                  <div className={`w-2 h-2 rounded-full transition-all ${
                    Math.abs(index - currentSlide) <= 2
                      ? 'bg-[#A9DFF7] hover:bg-[#6EC1E4] hover:scale-125'
                      : 'bg-[#E5E5E5] hover:bg-[#A9DFF7]'
                  }`}></div>
                )}
              </button>
            ))}
          </div>

          {/* Next Button */}
          <button
            onClick={goToNext}
            disabled={currentSlide === slides.length - 1}
            className={`group flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all font-['Inter'] text-sm ${
              currentSlide === slides.length - 1
                ? 'opacity-30 cursor-not-allowed text-[#4A5C6A]'
                : 'bg-[#6EC1E4] hover:bg-[#4A5C6A] text-white'
            }`}
          >
            <span className="hidden sm:inline">Next</span>
            <ChevronRight className={`w-4 h-4 transition-transform ${
              currentSlide !== slides.length - 1 ? 'group-hover:translate-x-0.5' : ''
            }`} />
          </button>
        </div>
      </div>
    </div>
  );
}
