export function Slide15Closing() {
  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-gradient-to-br from-[#2F2F2F] via-[#4A5C6A] to-[#2F2F2F] relative overflow-hidden flex items-center justify-center">
      
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] border border-[#6EC1E4] rounded-full"></div>
          <div className="absolute bottom-1/4 left-1/3 w-[300px] h-[300px] border-2 border-[#A9DFF7] rounded-full"></div>
        </div>
      </div>

      <div className="relative px-8 md:px-16 lg:px-24 py-16 text-center max-w-[900px]">
        
        {/* Main Message */}
        <h2 className="font-['Outfit'] text-[40px] md:text-[56px] lg:text-[72px] leading-[1.05] text-white tracking-tight mb-12">
          Let's Execute<br />Together
        </h2>

        {/* Description */}
        <p className="font-['Inter'] text-lg md:text-xl text-[#A9DFF7] leading-relaxed mb-16 max-w-[700px] mx-auto">
          Ready to bridge the gap between strategy and execution? Let's talk about how Footfall can elevate your brand's retail presence across Jamaica.
        </p>

        {/* Contact Section */}
        <div className="space-y-6 mb-12">
          
          {/* Email */}
          <div className="group">
            <div className="inline-flex items-center gap-3 px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full transition-all">
              <span className="font-['Inter'] text-sm uppercase tracking-wider text-[#A9DFF7]">Email</span>
              <div className="w-px h-4 bg-[#A9DFF7]"></div>
              <a 
                href="mailto:hello@footfall.services"
                className="font-['Inter'] text-lg text-white hover:text-[#6EC1E4] transition-colors"
              >
                hello@footfall.services
              </a>
            </div>
          </div>

          {/* Call to Action */}
          <div>
            <a
              href="mailto:hello@footfall.services?subject=BMaaS Inquiry"
              className="inline-flex items-center gap-3 px-10 py-4 bg-[#6EC1E4] hover:bg-[#A9DFF7] text-white hover:text-[#2F2F2F] rounded-full transition-all group shadow-lg hover:shadow-xl"
            >
              <span className="font-['Outfit'] text-lg">Get Started</span>
              <span className="transition-transform group-hover:translate-x-1">→</span>
            </a>
          </div>

        </div>

        {/* Tagline */}
        <div className="pt-8 border-t border-white/20">
          <p className="font-['Outfit'] text-xl text-[#6EC1E4]">
            FOOTFALL LIMITED
          </p>
          <p className="font-['Inter'] text-sm text-[#A9DFF7] mt-2">
            Trade Marketing · Field Operations · Retail Analytics
          </p>
        </div>

      </div>

      {/* Bottom Accent */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#6EC1E4] to-transparent"></div>
    </div>
  );
}
