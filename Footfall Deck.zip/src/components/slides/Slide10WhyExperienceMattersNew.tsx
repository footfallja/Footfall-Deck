export function Slide10WhyExperienceMattersNew() {
  const skills = [
    'Manage teams under pressure',
    'Maintain brand standards in unpredictable spaces',
    'Adapt to trade conditions in real time',
    'Solve problems quietly',
    'Keep crews energized and safe',
    'Bring discipline to environments that lack structure'
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-white px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
      <div className="mb-16">
        <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
          Why This Experience Matters
        </span>
        <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-[#2F2F2F] mb-6">
          We know<br />how to:
        </h2>
        <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-16 max-w-[1100px]">
        {skills.map((skill, index) => (
          <div
            key={index}
            className="p-6 border-l-4 border-[#A9DFF7] hover:border-[#6EC1E4] hover:bg-[#FAFAFA] transition-all"
          >
            <h3 className="font-['Outfit'] text-2xl md:text-3xl text-[#2F2F2F] leading-tight">
              {skill}
            </h3>
          </div>
        ))}
      </div>

      <div className="max-w-[700px] p-8 border-l-4 border-[#6EC1E4]">
        <p className="font-['Inter'] text-xl text-[#4A5C6A] mb-3">
          Experience isn't a feature.
        </p>
        <p className="font-['Outfit'] text-3xl md:text-4xl text-[#6EC1E4] leading-tight">
          It's our operating system.
        </p>
      </div>
    </div>
  );
}
