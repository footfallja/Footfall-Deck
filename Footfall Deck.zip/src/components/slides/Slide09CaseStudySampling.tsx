export function Slide09CaseStudySampling() {
  const metrics = [
    { value: '120', label: 'Stores Covered', unit: '' },
    { value: '15,000+', label: 'Samples Distributed', unit: '' },
    { value: '92%', label: 'Compliance Rate', unit: '' }
  ];

  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-[#FAFAFA] relative overflow-hidden">
      
      <div className="h-full flex flex-col justify-center px-8 md:px-16 lg:px-24 xl:px-32 py-16 lg:py-20">
        
        {/* Case Study Label */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-3 bg-white border-2 border-[#6EC1E4] text-[#6EC1E4] px-4 py-2 rounded-full">
            <span className="font-['Inter'] text-xs uppercase tracking-wider">Case Study 02</span>
          </div>
        </div>

        {/* Title */}
        <h2 className="font-['Outfit'] text-[40px] md:text-[52px] lg:text-[64px] leading-[1.05] text-[#2F2F2F] tracking-tight mb-6">
          In-Store Sampling<br />Program
        </h2>

        {/* Description */}
        <p className="font-['Inter'] text-lg md:text-xl text-[#4A5C6A] leading-relaxed mb-12 max-w-[700px]">
          Three-month sampling campaign for a beverage brand across supermarkets, pharmacies, and convenience stores nationwide.
        </p>

        {/* Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 lg:gap-12 max-w-[900px]">
          {metrics.map((metric, index) => (
            <div key={index} className="group bg-white p-6 rounded-xl border border-[#E5E5E5] hover:border-[#6EC1E4] transition-all">
              <div className="mb-3">
                <span className="font-['Outfit'] text-[42px] md:text-[48px] leading-none text-[#2F2F2F] block">
                  {metric.value}
                </span>
              </div>
              <div className="font-['Inter'] text-sm md:text-base text-[#4A5C6A] leading-tight">
                {metric.label}
              </div>
            </div>
          ))}
        </div>

        {/* Key Insight */}
        <div className="mt-12 p-6 bg-white rounded-xl border-l-4 border-[#6EC1E4] max-w-[700px]">
          <p className="font-['Inter'] text-base text-[#2F2F2F]">
            <span className="text-[#6EC1E4]">Key Result:</span> 42% increase in brand awareness in sampled stores vs. control group.
          </p>
        </div>

      </div>
    </div>
  );
}
