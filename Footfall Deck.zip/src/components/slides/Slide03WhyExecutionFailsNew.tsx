export function Slide03WhyExecutionFailsNew() {
  const globalIssues = [
    'Visibility drops',
    'Displays collapse',
    'Activation plans fail',
    'Issues surface too late'
  ];

  const jamaicaIssues = [
    'Promoters create guesswork, not data.',
    'Trade activities aren\'t verified in real time.',
    'Reports get dressed up.',
    'No one supervises.'
  ];

  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#4A5C6A] to-[#2F2F2F]"></div>

      {/* Content */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32">
        <div className="mb-16">
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
            Why Execution<br />Fails
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-[1100px]">
          {/* Global */}
          <div>
            <div className="mb-6">
              <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4]">
                Global Reality
              </span>
            </div>
            <h3 className="font-['Outfit'] text-2xl md:text-3xl text-white mb-8">
              Brands lose revenue when execution breaks:
            </h3>
            <div className="space-y-4">
              {globalIssues.map((issue, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-3 flex-shrink-0"></div>
                  <span className="font-['Inter'] text-lg md:text-xl text-[#A9DFF7] leading-relaxed">
                    {issue}
                  </span>
                </div>
              ))}
            </div>
            <p className="font-['Inter'] text-sm text-[rgb(255,255,255)] italic mt-8 text-[14px]">
              Source: NielsenIQ, McKinsey & global retail execution studies.
            </p>
          </div>

          {/* Jamaica */}
          <div>
            <div className="mb-6">
              <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4]">
                Jamaica Reality
              </span>
            </div>
            <h3 className="font-['Outfit'] text-2xl md:text-3xl text-white mb-8">
              In Jamaica, the gaps widen:
            </h3>
            <div className="space-y-5">
              {jamaicaIssues.map((issue, index) => (
                <p key={index} className="font-['Inter'] text-lg md:text-xl text-[#A9DFF7] leading-relaxed">
                  {issue}
                </p>
              ))}
            </div>
            <div className="mt-10 p-6 border-l-4 border-[#6EC1E4]">
              <p className="font-['Outfit'] text-xl md:text-2xl text-white leading-tight">
                This is the execution gap.
                <br />
                This is where brands lose money.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
