export function Slide12BMaaSTiersNew() {
  const tiers = [
    {
      name: 'STARTER',
      executions: '4 recommended executions/month',
      price: 'JMD $250k–$350k',
    },
    {
      name: 'CORE',
      executions: '6-8 recommended executions/month',
      price: 'JMD $400k–$700k',
      highlight: true,
    },
    {
      name: 'FULL COVERAGE',
      executions: '10 recommended executions/month',
      price: 'JMD $750k–$1.2M+',
    },
  ];

  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background with geometric pattern */}
      <div className="absolute inset-0 bg-[#2F2F2F]">
        {/* Geometric lines */}
        <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
          <line x1="0" y1="0" x2="100%" y2="100%" stroke="#6EC1E4" strokeWidth="1" />
          <line x1="100%" y1="0" x2="0" y2="100%" stroke="#6EC1E4" strokeWidth="1" />
          <circle cx="50%" cy="50%" r="30%" fill="none" stroke="#6EC1E4" strokeWidth="1" />
        </svg>
      </div>

      {/* Content */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32">
        <div className="mb-16">
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
            BMaaS Tiers
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {tiers.map((tier, index) => (
            <div
              key={index}
              className={`p-8 border-2 rounded-2xl transition-all ${
                tier.highlight 
                  ? 'bg-[#6EC1E4] border-[#6EC1E4]' 
                  : 'bg-[#4A5C6A]/30 border-[#6EC1E4]/30 hover:border-[#6EC1E4]'
              }`}
            >
              <h3 className={`font-['Outfit'] text-2xl md:text-3xl mb-6 ${
                tier.highlight ? 'text-white' : 'text-[#6EC1E4]'
              }`}>
                {tier.name}
              </h3>
              <p className={`font-['Inter'] text-lg mb-6 leading-relaxed ${
                tier.highlight ? 'text-white' : 'text-white'
              }`}>
                {tier.executions}
              </p>
              <p className={`font-['Outfit'] text-2xl md:text-3xl ${
                tier.highlight ? 'text-[#2F2F2F]' : 'text-[#A9DFF7]'
              }`}>
                {tier.price}
              </p>
            </div>
          ))}
        </div>

        <div className="max-w-[600px] p-6 border-l-4 border-[#6EC1E4] bg-[#4A5C6A]/20">
          <p className="font-['Inter'] text-lg text-[#A9DFF7] leading-relaxed">
            Retainer covers management.<br />
            Field execution is billed seperately.
          </p>
        </div>
      </div>
    </div>
  );
}
