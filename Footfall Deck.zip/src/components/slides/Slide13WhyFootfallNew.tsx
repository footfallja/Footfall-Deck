export function Slide13WhyFootfallNew() {
  const reasons = [
    'Execution without excuses.',
    'Structure where brands need it.',
    'Control where trade breaks.',
    'Data instead of guesswork.',
    'Teams that don\'t fall apart.',
    'Your brand — properly executed.'
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-white px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
      <div className="mb-16">
        <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
          Why Choose Us
        </span>
        <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-[#2F2F2F] mb-6">
          Why Footfall
        </h2>
        <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
      </div>

      <div className="grid md:grid-cols-2 gap-x-12 gap-y-10 max-w-[1000px]">
        {reasons.map((reason, index) => (
          <div 
            key={index}
            className="group flex items-start gap-6 p-6 rounded-xl hover:bg-[#FAFAFA] transition-all"
          >
            {/* Number */}
            <div className="flex-shrink-0">
              <div className="w-10 h-10 rounded-full bg-[#6EC1E4] flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="font-['Outfit'] text-sm text-white">
                  {String(index + 1).padStart(2, '0')}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 pt-1">
              <p className="font-['Inter'] text-xl md:text-2xl text-[#2F2F2F] leading-relaxed">
                {reason}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
