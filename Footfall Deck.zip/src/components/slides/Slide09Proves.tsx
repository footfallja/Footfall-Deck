export function Slide09Proves() {
  const capabilities = [
    'Multi-day coordination',
    'Large team deployment',
    'Real-time fixes',
    'Safe, efficient executions',
    'Stock discipline',
    'Brand protected',
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-[#2F2F2F] px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
      <div className="mb-12">
        <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
          What Case Study<br />Proves
        </h2>
        <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-8"></div>
        <p className="font-['Outfit'] text-3xl md:text-4xl text-[#A9DFF7] mb-16">
          Footfall = field operations. Not just promoters
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-x-20 gap-y-6 max-w-[900px] mb-16">
        {capabilities.map((capability, index) => (
          <div key={index} className="flex items-start gap-4">
            <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-3 flex-shrink-0"></div>
            <span className="font-['Inter'] text-xl md:text-2xl text-white leading-relaxed">
              {capability}
            </span>
          </div>
        ))}
      </div>

      <div className="pt-8 border-t border-[#4A5C6A]">
        <p className="font-['Inter'] text-lg text-[#A9DFF7]">
        </p>
      </div>
    </div>
  );
}
