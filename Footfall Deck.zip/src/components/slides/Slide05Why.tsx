export function Slide05Why() {
  const reasons = [
    'Promoters that execute',
    'Consistent delivery',
    'Real reporting',
    'Data analytics',
    'Zero surprises',
    'One accountable partner',
  ];

  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1657819547860-ea03df0eafa8?w=1920&auto=format&q=75"
          alt="Supervisor with tablet"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#2F2F2F]/95 via-[#2F2F2F]/90 to-transparent"></div>
      </div>

      {/* Content - Left aligned */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
        <div className="max-w-[700px]">
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
            Why Brands<br />Work With<br />Footfall
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-16"></div>

          <div className="space-y-5">
            {reasons.map((reason, index) => (
              <div key={index} className="flex items-start gap-4">
                <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-3 flex-shrink-0"></div>
                <span className="font-['Inter'] text-xl md:text-2xl text-white leading-relaxed">
                  {reason}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
