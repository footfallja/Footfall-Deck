export function Slide10CaseStudySumfest() {
  const metrics = [
    { value: '40', label: 'Store Activations', unit: '' },
    { value: '12K+', label: 'Brand Engagements', unit: '' },
    { value: '5,800+', label: 'Units Moved', unit: '' }
  ];

  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-white relative overflow-hidden">
      
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=1920&auto=format&q=75"
          alt="Music festival crowd energy"
          className="w-full h-full object-cover opacity-10"
          loading="lazy"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-white via-white/95 to-white/80"></div>
      </div>

      <div className="relative h-full flex flex-col justify-center px-8 md:px-16 lg:px-24 xl:px-32 py-16 lg:py-20">
        
        <div className="max-w-[1100px]">
          {/* Case Study Label */}
          <div className="mb-6">
            <div className="inline-flex items-center gap-3 bg-[#2F2F2F] text-white px-4 py-2 rounded-full">
              <span className="font-['Inter'] text-xs uppercase tracking-wider">Case Study 03</span>
            </div>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            
            {/* Left: Content */}
            <div>
              <h2 className="font-['Outfit'] text-[40px] md:text-[52px] lg:text-[56px] leading-[1.05] text-[#2F2F2F] tracking-tight mb-6">
                STR8 VYBZ<br />Sumfest 2024
              </h2>

              <p className="font-['Inter'] text-lg md:text-xl text-[#4A5C6A] leading-relaxed mb-8">
                Pre-event retail activation across Western Jamaica, building brand presence ahead of the island's biggest music festival.
              </p>

              <div className="inline-flex items-center gap-2 px-5 py-3 bg-[#6EC1E4]/10 rounded-lg">
                <span className="font-['Inter'] text-sm text-[#2F2F2F]">
                  Duration: 2 weeks | Coverage: Western Jamaica
                </span>
              </div>
            </div>

            {/* Right: Metrics */}
            <div className="space-y-6">
              {metrics.map((metric, index) => (
                <div 
                  key={index} 
                  className="flex items-center gap-6 p-6 bg-[#FAFAFA] rounded-xl border border-[#E5E5E5] hover:border-[#6EC1E4] transition-all group"
                >
                  <div className="flex-shrink-0">
                    <span className="font-['Outfit'] text-[40px] leading-none text-[#6EC1E4] block">
                      {metric.value}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="font-['Inter'] text-base text-[#2F2F2F]">
                      {metric.label}
                    </div>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-[#6EC1E4] opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              ))}
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
