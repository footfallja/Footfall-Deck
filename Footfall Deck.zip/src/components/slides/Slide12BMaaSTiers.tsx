export function Slide12BMaaSTiers() {
  const tiers = [
    {
      name: 'STARTER',
      executions: '4 recommended executions/month',
      price: 'JMD $250k–$350k'
    },
    {
      name: 'CORE',
      executions: '6-8 recommended executions/month',
      price: 'JMD $400k–$700k'
    },
    {
      name: 'FULL COVERAGE',
      executions: '10 recommended executions/month',
      price: 'JMD $750k–$1.2M+'
    }
  ];

  return (
    <div className="w-full aspect-[16/9] bg-white relative overflow-hidden">
      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px]">
        
        {/* Header */}
        <div className="mb-12">
          <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-6">
            BMaaS PRICING TIERS
          </p>
          <h2 className="font-['Outfit'] text-[52px] leading-[1.1] text-[#2F2F2F]">
            Choose Your Coverage
          </h2>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-3 gap-[24px] mb-8">
          {tiers.map((tier, index) => (
            <div 
              key={index}
              className="border-2 border-[#2F2F2F]/10 hover:border-[#6EC1E4] transition-all p-8 rounded-lg"
            >
              <h3 className="font-['Outfit'] text-[24px] text-[#6EC1E4] mb-8">
                {tier.name}
              </h3>
              
              <p className="font-['Inter'] text-[16px] text-[#4A5C6A] leading-relaxed mb-10 min-h-[48px]">
                {tier.executions}
              </p>
              
              <p className="font-['Outfit'] text-[28px] text-[#2F2F2F] leading-tight">
                {tier.price}
              </p>
            </div>
          ))}
        </div>

        {/* Footer Note */}
        <div className="border-l-4 border-[#6EC1E4] pl-6 max-w-[800px]">
          <p className="font-['Inter'] text-[18px] text-[#4A5C6A] leading-relaxed">
            Retainer covers management.
            <br />
            Field execution is billed seperately.
          </p>
        </div>
      </div>
    </div>
  );
}
