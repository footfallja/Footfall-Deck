export function Slide11Engage() {
  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1668713239048-0746aac1fec1?w=1920&auto=format&q=75"
          alt="Planning workspace"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#2F2F2F]/95 to-[#4A5C6A]/90"></div>
      </div>

      {/* Content */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
        <div className="max-w-[800px]">
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
            How Clients<br />Engage Us
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-16"></div>

          <div className="space-y-12">
            <div className="p-8 bg-[#2F2F2F]/70 border-l-4 border-[#6EC1E4]">
              <h3 className="font-['Outfit'] text-3xl text-white mb-4">
                Management <span className="text-[#A9DFF7]">(Retainer)</span>
              </h3>
              <p className="font-['Inter'] text-xl text-[#A9DFF7] leading-relaxed">
                Planning • Coordination • Reporting • Supervision
              </p>
            </div>

            <div className="p-8 bg-[#2F2F2F]/70 border-l-4 border-[#A9DFF7]">
              <h3 className="font-['Outfit'] text-3xl text-white mb-4">
                Execution <span className="text-[#A9DFF7]">(Add-ons)</span>
              </h3>
              <p className="font-['Inter'] text-xl text-[#A9DFF7] leading-relaxed">
                Promoters • Merch visits • Supervisors • Activations
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
