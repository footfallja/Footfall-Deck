import { ShoppingCart, Package, Users, ClipboardList, MapPin, FileCheck, AlertCircle } from 'lucide-react';

export function Slide06FootfallRoleNew() {
  const services = [
    { icon: ShoppingCart, title: 'In-field activations' },
    { icon: Package, title: 'Trade-space merchandising' },
    { icon: Users, title: 'Sampling programs' },
    { icon: MapPin, title: 'Coverage mapping' },
    { icon: ClipboardList, title: 'Field team management' },
    { icon: FileCheck, title: 'Reporting and verification' },
    { icon: AlertCircle, title: 'Issue resolution' },
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-white px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
      <div className="mb-16">
        <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-[#2F2F2F] mb-3">
          We do the work.
        </h2>
        <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-8"></div>
        <p className="font-['Inter'] text-xl md:text-2xl text-[#4A5C6A] leading-relaxed max-w-[800px]">
          Footfall is the operations layer that keeps your trade marketing alive across any environment:
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12 max-w-[1100px]">
        {services.map((service, index) => {
          const Icon = service.icon;
          return (
            <div
              key={index}
              className="p-6 border-2 border-[#A9DFF7] rounded-2xl hover:border-[#6EC1E4] hover:bg-[#FAFAFA] transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-[#6EC1E4] flex items-center justify-center mb-4">
                <Icon className="w-6 h-6 text-white" strokeWidth={2} />
              </div>
              <h4 className="font-['Outfit'] text-xl text-[#2F2F2F]">
                {service.title}
              </h4>
            </div>
          );
        })}
      </div>

      <div className="max-w-[600px] p-6 border-l-4 border-[#6EC1E4]">
        <p className="font-['Outfit'] text-2xl md:text-3xl text-[#2F2F2F] leading-tight">
          Execution, not guesswork.
        </p>
      </div>
    </div>
  );
}
