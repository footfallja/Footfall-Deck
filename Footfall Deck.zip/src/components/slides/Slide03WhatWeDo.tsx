import { ShoppingCart, Package, Users, ClipboardList } from 'lucide-react';

export function Slide03WhatWeDo() {
  const services = [
    { icon: ShoppingCart, title: 'In-store activations' },
    { icon: Package, title: 'Merchandising operations' },
    { icon: Users, title: 'Field team management' },
    { icon: ClipboardList, title: 'Retail reporting' },
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-white px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
      <div className="mb-16">
        <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-[#2F2F2F] mb-6">
          What We Do
        </h2>
        <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
      </div>

      {/* Asymmetric grid - 2 columns with offset */}
      <div className="grid md:grid-cols-2 gap-8 max-w-[900px]">
        {services.map((service, index) => {
          const Icon = service.icon;
          return (
            <div
              key={index}
              className="p-6 border-2 border-[#A9DFF7] rounded-2xl hover:border-[#6EC1E4] transition-all"
            >
              <div className="w-14 h-14 rounded-xl bg-[#6EC1E4] flex items-center justify-center mb-5">
                <Icon className="w-7 h-7 text-white" strokeWidth={2} />
              </div>
              <h4 className="font-['Outfit'] text-2xl md:text-3xl text-[#2F2F2F]">
                {service.title}
              </h4>
            </div>
          );
        })}
      </div>
    </div>
  );
}