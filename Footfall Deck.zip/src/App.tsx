import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Slide01CoverNew } from './components/slides/Slide01CoverNew';
import { Slide02BreakpointNew } from './components/slides/Slide02BreakpointNew';
import { Slide03WhyExecutionFailsNew } from './components/slides/Slide03WhyExecutionFailsNew';
import { Slide04JamaicanRealityNew } from './components/slides/Slide04JamaicanRealityNew';
import { Slide05GapInMarketNew } from './components/slides/Slide05GapInMarketNew';
import { Slide06FootfallRoleNew } from './components/slides/Slide06FootfallRoleNew';
import { Slide07HowFootfallExecutesNew } from './components/slides/Slide07HowFootfallExecutesNew';
import { Slide08OurExperienceNew } from './components/slides/Slide08OurExperienceNew';
import { Slide09WhatWeExecutedNew } from './components/slides/Slide09WhatWeExecutedNew';
import { Slide10WhyExperienceMattersNew } from './components/slides/Slide10WhyExperienceMattersNew';
import { Slide11BMaaSNew } from './components/slides/Slide11BMaaSNew';
import { Slide12BMaaSTiersNew } from './components/slides/Slide12BMaaSTiersNew';
import { Slide13WhyFootfallNew } from './components/slides/Slide13WhyFootfallNew';
import { Slide14ClosingNew } from './components/slides/Slide14ClosingNew';

const slides = [
  { id: 1, component: Slide01CoverNew, title: 'Cover' },
  { id: 2, component: Slide02BreakpointNew, title: 'The Breakpoint' },
  { id: 3, component: Slide03WhyExecutionFailsNew, title: 'Why Execution Fails' },
  { id: 4, component: Slide04JamaicanRealityNew, title: 'Jamaican Reality' },
  { id: 5, component: Slide05GapInMarketNew, title: 'Gap in Market' },
  { id: 6, component: Slide06FootfallRoleNew, title: 'Our Role' },
  { id: 7, component: Slide07HowFootfallExecutesNew, title: 'How We Execute' },
  { id: 8, component: Slide08OurExperienceNew, title: 'Our Experience' },
  { id: 9, component: Slide09WhatWeExecutedNew, title: 'What We\'ve Executed' },
  { id: 10, component: Slide10WhyExperienceMattersNew, title: 'Why Experience Matters' },
  { id: 11, component: Slide11BMaaSNew, title: 'BMaaS' },
  { id: 12, component: Slide12BMaaSTiersNew, title: 'Pricing Tiers' },
  { id: 13, component: Slide13WhyFootfallNew, title: 'Why Footfall' },
  { id: 14, component: Slide14ClosingNew, title: 'Get in Touch' },
];

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goToSlide = (index: number) => {
    if (index >= 0 && index < slides.length && index !== currentSlide) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentSlide(index);
        setTimeout(() => setIsTransitioning(false), 50);
      }, 200);
    }
  };

  const goToNext = () => goToSlide(currentSlide + 1);
  const goToPrevious = () => goToSlide(currentSlide - 1);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') goToNext();
      if (e.key === 'ArrowLeft') goToPrevious();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  const CurrentSlideComponent = slides[currentSlide].component;

  return (
    <div className="min-h-screen bg-[#FAFAFA] flex flex-col">
      {/* Minimal Top Bar */}
      <div className="bg-white border-b border-[#E5E5E5] px-8 py-5 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-2 h-8 bg-[#6EC1E4] rounded-full"></div>
          <span className="font-['Outfit'] text-lg tracking-tight text-[#2F2F2F]">
            FOOTFALL LIMITED
          </span>
        </div>
        <div className="flex items-center gap-6 text-sm text-[#4A5C6A] font-['Inter']">
          <span className="hidden md:inline">{slides[currentSlide].title}</span>
          <span className="bg-[#F5F5F5] px-3 py-1 rounded-full">
            {String(currentSlide + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
          </span>
        </div>
      </div>

      {/* Main Slide Container */}
      <div className="flex-1 relative overflow-hidden bg-white">
        <div 
          className={`w-full h-full transition-opacity duration-200 ${
            isTransitioning ? 'opacity-0' : 'opacity-100'
          }`}
        >
          <CurrentSlideComponent />
        </div>
      </div>

      {/* Modern Bottom Navigation */}
      <div className="bg-white border-t border-[#E5E5E5] px-8 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
          {/* Previous Button */}
          <button
            onClick={goToPrevious}
            disabled={currentSlide === 0}
            className={`group flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all font-['Inter'] text-sm ${
              currentSlide === 0
                ? 'opacity-30 cursor-not-allowed text-[#4A5C6A]'
                : 'hover:bg-[#F5F5F5] text-[#2F2F2F]'
            }`}
          >
            <ChevronLeft className={`w-4 h-4 transition-transform ${
              currentSlide !== 0 ? 'group-hover:-translate-x-0.5' : ''
            }`} />
            <span className="hidden sm:inline">Previous</span>
          </button>

          {/* Dot Indicators */}
          <div className="flex-1 flex items-center justify-center gap-2 overflow-x-auto py-2 px-4">
            {slides.map((slide, index) => (
              <button
                key={slide.id}
                onClick={() => goToSlide(index)}
                className="group relative flex items-center justify-center"
                aria-label={`Go to slide ${index + 1}`}
              >
                {index === currentSlide ? (
                  <div className="flex items-center gap-2 bg-[#6EC1E4] px-4 py-1.5 rounded-full transition-all">
                    <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                    <span className="text-white font-['Inter'] text-xs">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                  </div>
                ) : (
                  <div className={`w-2 h-2 rounded-full transition-all ${
                    Math.abs(index - currentSlide) <= 2
                      ? 'bg-[#A9DFF7] hover:bg-[#6EC1E4] hover:scale-125'
                      : 'bg-[#E5E5E5] hover:bg-[#A9DFF7]'
                  }`}></div>
                )}
              </button>
            ))}
          </div>

          {/* Next Button */}
          <button
            onClick={goToNext}
            disabled={currentSlide === slides.length - 1}
            className={`group flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all font-['Inter'] text-sm ${
              currentSlide === slides.length - 1
                ? 'opacity-30 cursor-not-allowed text-[#4A5C6A]'
                : 'bg-[#6EC1E4] hover:bg-[#4A5C6A] text-white'
            }`}
          >
            <span className="hidden sm:inline">Next</span>
            <ChevronRight className={`w-4 h-4 transition-transform ${
              currentSlide !== slides.length - 1 ? 'group-hover:translate-x-0.5' : ''
            }`} />
          </button>
        </div>
      </div>
    </div>
  );
}
