# 🚀 Deployment Guide for Footfall Presentation

## Option 1: Vercel (Recommended - Easiest)

### What you'll get:
- Free hosting
- Automatic HTTPS
- Custom domain support
- URL like: `footfall-presentation.vercel.app`

### Steps:

1. **Download Your Project**
   - In Figma Make, download/export all project files to your computer

2. **Create a GitHub Account** (if you don't have one)
   - Go to [github.com/join](https://github.com/join)
   - Sign up for free

3. **Create a New Repository**
   - Click the "+" icon in the top right → "New repository"
   - Name: `footfall-presentation`
   - Choose Public or Private
   - Don't add README, .gitignore, or license (we already have files)
   - Click "Create repository"

4. **Upload Your Files to GitHub**
   
   **Easy Method (GitHub Website):**
   - On your new repository page, click "uploading an existing file"
   - Drag all your project files into the browser
   - Click "Commit changes"

   **Alternative (GitHub Desktop - if you prefer):**
   - Download [GitHub Desktop](https://desktop.github.com)
   - Clone your repository
   - Copy all project files into the folder
   - Commit and push

5. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "Sign Up" → Sign in with GitHub
   - Click "Add New..." → "Project"
   - Find and select your `footfall-presentation` repository
   - Vercel will auto-detect everything - just click "Deploy"
   - Wait 1-2 minutes ☕

6. **Get Your Link**
   - Once deployed, you'll see your URL
   - Click "Visit" to see your presentation live
   - Share the URL with anyone!

### Updating After Changes:
Just push new code to GitHub and Vercel automatically redeploys!

---

## Option 2: Netlify (Alternative)

1. **Download Your Project** (same as above)

2. **Build Your Project Locally** (optional but recommended)
   ```bash
   npm install
   npm run build
   ```
   This creates a `dist` folder

3. **Deploy to Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Sign up for free
   - Drag the `dist` folder onto the Netlify dashboard
   - Done! You get a URL instantly

---

## Option 3: GitHub Pages (Free Forever)

1. **Push to GitHub** (steps 1-4 from Vercel above)

2. **Enable GitHub Pages**
   - In your repository, go to Settings → Pages
   - Source: Deploy from branch
   - Branch: select `main` and `/root`
   - Click Save

3. **Add GitHub Actions Workflow**
   Create `.github/workflows/deploy.yml`:
   ```yaml
   name: Deploy
   on:
     push:
       branches: [main]
   jobs:
     build-and-deploy:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v2
         - uses: actions/setup-node@v2
           with:
             node-version: '18'
         - run: npm install
         - run: npm run build
         - uses: peaceiris/actions-gh-pages@v3
           with:
             github_token: ${{ secrets.GITHUB_TOKEN }}
             publish_dir: ./dist
   ```

4. **Your URL:** `https://yourusername.github.io/footfall-presentation`

---

## 🎯 Which Should You Choose?

| Platform | Best For | Speed | Custom Domain |
|----------|----------|-------|---------------|
| **Vercel** | Most users | ⚡⚡⚡ Fast | ✅ Free |
| **Netlify** | Quick drag-drop | ⚡⚡⚡ Fast | ✅ Free |
| **GitHub Pages** | Tech-savvy users | ⚡⚡ Medium | ✅ Free |

**Recommendation:** Start with **Vercel** - it's the easiest and most reliable.

---

## 📞 Need Help?

If you get stuck:
1. Check that all files were uploaded to GitHub
2. Make sure the repository is not empty
3. Vercel should auto-detect "Vite" as the framework
4. Build command should be: `npm run build`
5. Output directory should be: `dist`

---

## ✅ Checklist Before Deploying

- [ ] All custom images are using the correct URLs (not placeholders)
- [ ] Contact information on Slide 14 is correct
- [ ] You've tested the presentation locally (optional)
- [ ] All 14 slides look correct
- [ ] Navigation works (arrows, dots, keyboard)

---

## 🎉 After Deployment

Share your link:
- `https://footfall-presentation.vercel.app` (or your custom URL)
- Works on any device
- No login required for viewers
- Professional and fast

**Pro tip:** You can add a custom domain (like `deck.footfallja.com`) in Vercel settings for free!
