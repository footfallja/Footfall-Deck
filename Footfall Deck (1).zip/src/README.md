# Footfall Limited - Trade Marketing Presentation Deck

A premium 14-slide presentation showcasing Footfall Limited's trade marketing services, built with React and Tailwind CSS.

## 🚀 Quick Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone)

### Step-by-Step Deployment Instructions:

1. **Download this project** from Figma Make
   - Click the download/export button to get all project files

2. **Create a GitHub repository:**
   - Go to [github.com](https://github.com) and sign in (or create an account)
   - Click "New repository"
   - Name it `footfall-presentation` (or any name you prefer)
   - Make it public or private (your choice)
   - Click "Create repository"

3. **Upload your code to GitHub:**
   - Download GitHub Desktop or use the command line
   - Push all your downloaded project files to the repository

4. **Deploy to Vercel:**
   - Go to [vercel.com](https://vercel.com) and sign up (free account)
   - Click "Add New..." → "Project"
   - Import your GitHub repository
   - Vercel will auto-detect settings - just click "Deploy"
   - Wait 1-2 minutes for deployment to complete

5. **Share your link!**
   - You'll get a URL like `footfall-presentation.vercel.app`
   - Share this link with anyone to view your presentation

## 📱 Features

- **14 Premium Slides** covering Footfall's complete service offering
- **Fully Responsive** - works on desktop, tablet, and mobile
- **Keyboard Navigation** - use arrow keys to navigate
- **Click Navigation** - click dots or use Previous/Next buttons
- **Smooth Transitions** - professional fade effects between slides
- **Custom Images** - all slides use specified custom images

## 🎨 Design System

- **Colors:** Sky Blue (#6EC1E4), Charcoal Gray (#2F2F2F), Slate Blue Gray (#4A5C6A)
- **Typography:** Outfit (headings), Inter (body text)
- **Style:** Luxury-modern, editorial, minimalistic with high contrast

## 🛠️ Local Development

If you want to run this locally:

```bash
npm install
npm run dev
```

Then open http://localhost:5173 in your browser.

## 📋 Slide Overview

1. Cover - Introduction to Footfall Limited
2. The Breakpoint - Market reality
3. Why Execution Fails - Common challenges
4. Jamaican Reality - Local market context
5. Gap in Market - The opportunity
6. Our Role - How Footfall fits
7. How We Execute - 5-step process + Pulse360
8. Our Experience - Track record
9. What We've Executed - Case examples
10. Why Experience Matters - Proof points
11. BMaaS Introduction - Brand Manager as a Service
12. Pricing Tiers - Three service levels
13. Why Footfall - Key differentiators
14. Get in Touch - Contact information

## 📞 Contact

**Footfall Limited**  
Building reliable trade execution across Jamaica.

---

Built with React + Vite + Tailwind CSS
