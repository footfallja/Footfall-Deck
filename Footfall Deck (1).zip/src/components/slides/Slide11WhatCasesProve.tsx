export function Slide11WhatCasesProve() {
  const proofs = [
    {
      title: 'Execution at Scale',
      description: 'We\'ve successfully managed 185+ store activations across Jamaica\'s diverse retail landscape.'
    },
    {
      title: 'Measurable Results',
      description: 'Every activation is documented, verified, and reported with store-level precision.'
    },
    {
      title: 'Cultural Fluency',
      description: 'Our teams understand Jamaican retail culture and navigate it effectively for your brand.'
    },
    {
      title: 'Reliability',
      description: 'Consistent execution without excuses, even in Jamaica\'s most challenging retail environments.'
    }
  ];

  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-[#2F2F2F] relative overflow-hidden flex items-center px-8 md:px-16 lg:px-24 xl:px-32 py-16">
      
      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden opacity-5">
        <div className="absolute -top-1/4 -right-1/4 w-[800px] h-[800px] border border-[#6EC1E4] rounded-full"></div>
        <div className="absolute -bottom-1/4 -left-1/4 w-[600px] h-[600px] border border-[#A9DFF7] rounded-full"></div>
      </div>

      <div className="relative w-full max-w-[1100px] mx-auto">
        
        {/* Header */}
        <div className="mb-16">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
            Track Record
          </span>
          <h2 className="font-['Outfit'] text-[40px] md:text-[52px] lg:text-[64px] leading-[1.05] text-white tracking-tight">
            What These Cases Prove
          </h2>
        </div>

        {/* Proofs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {proofs.map((proof, index) => (
            <div 
              key={index}
              className="group p-8 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/10 hover:border-[#6EC1E4] transition-all"
            >
              {/* Number */}
              <div className="mb-6">
                <span className="font-['Outfit'] text-sm text-[#6EC1E4] tracking-wider">
                  {String(index + 1).padStart(2, '0')}
                </span>
              </div>

              {/* Title */}
              <h3 className="font-['Outfit'] text-2xl text-white mb-4 leading-tight">
                {proof.title}
              </h3>

              {/* Description */}
              <p className="font-['Inter'] text-base text-[#A9DFF7] leading-relaxed">
                {proof.description}
              </p>

              {/* Decorative Element */}
              <div className="w-0 group-hover:w-12 h-px bg-[#6EC1E4] transition-all duration-500 mt-6"></div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}