export function Slide07HowFootfallExecutes() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-15">
        <img 
          src="https://images.unsplash.com/photo-1697545805858-556ce0a508cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXBlcnZpc29yJTIwdGFibGV0JTIwcmV0YWlsfGVufDF8fHx8MTc2NTQyODQ4M3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Supervisor verifying execution"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px]">
        <div className="grid grid-cols-12 gap-[24px]">
          
          {/* Left - Process */}
          <div className="col-span-5">
            <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-8">
              HOW FOOTFALL EXECUTES
            </p>

            <div className="space-y-8">
              {['Plan', 'Deploy', 'Execute', 'Verify', 'Report'].map((step, index) => (
                <div key={index} className="flex items-center gap-6">
                  <div className="w-12 h-12 rounded-full bg-[#6EC1E4] flex items-center justify-center flex-shrink-0">
                    <span className="font-['Outfit'] text-[18px] text-[#2F2F2F]">
                      {index + 1}
                    </span>
                  </div>
                  <h3 className="font-['Outfit'] text-[32px] text-white">
                    {step}
                  </h3>
                </div>
              ))}
            </div>
          </div>

          {/* Right - Description */}
          <div className="col-span-6 col-start-7 flex flex-col justify-center">
            <div className="space-y-6 mb-12">
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] leading-relaxed">
                Every shift supervised.
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] leading-relaxed">
                Every touchpoint documented.
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] leading-relaxed">
                Every issue solved before it reaches you.
              </p>
            </div>

            <div className="bg-white/5 border border-[#6EC1E4]/30 rounded-lg p-8">
              <p className="font-['Outfit'] text-[24px] text-[#6EC1E4] mb-3">
                Pulse360 (Coming)
              </p>
              <p className="font-['Inter'] text-[16px] text-white leading-relaxed">
                Real-time attendance, photos, tasks, and trade-space intelligence.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
