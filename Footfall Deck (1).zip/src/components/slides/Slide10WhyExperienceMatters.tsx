export function Slide10WhyExperienceMatters() {
  return (
    <div className="w-full aspect-[16/9] bg-white relative overflow-hidden">
      {/* Content - Asymmetric Editorial Layout */}
      <div className="relative h-full px-[120px] py-[80px]">
        <div className="grid grid-cols-12 gap-[24px]">
          
          {/* Left - Headline */}
          <div className="col-span-5">
            <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-8">
              WHY THIS EXPERIENCE MATTERS
            </p>

            <h2 className="font-['Outfit'] text-[52px] leading-[1.1] text-[#2F2F2F]">
              We know how to:
            </h2>
          </div>

          {/* Right - Content */}
          <div className="col-span-6 col-start-7 flex flex-col justify-center">
            <div className="space-y-8">
              <div>
                <h3 className="font-['Outfit'] text-[24px] text-[#2F2F2F] mb-2">
                  Manage teams under pressure
                </h3>
              </div>

              <div>
                <h3 className="font-['Outfit'] text-[24px] text-[#2F2F2F] mb-2">
                  Maintain brand standards in unpredictable spaces
                </h3>
              </div>

              <div>
                <h3 className="font-['Outfit'] text-[24px] text-[#2F2F2F] mb-2">
                  Adapt to trade conditions in real time
                </h3>
              </div>

              <div>
                <h3 className="font-['Outfit'] text-[24px] text-[#2F2F2F] mb-2">
                  Solve problems quietly
                </h3>
              </div>

              <div>
                <h3 className="font-['Outfit'] text-[24px] text-[#2F2F2F] mb-2">
                  Keep crews energized and safe
                </h3>
              </div>

              <div>
                <h3 className="font-['Outfit'] text-[24px] text-[#2F2F2F] mb-2">
                  Bring discipline to environments that lack structure
                </h3>
              </div>
            </div>

            <div className="mt-16 pt-8 border-t-2 border-[#6EC1E4]">
              <p className="font-['Inter'] text-[20px] text-[#4A5C6A] mb-3">
                Experience isn't a feature.
              </p>
              <p className="font-['Outfit'] text-[32px] text-[#6EC1E4] leading-tight">
                It's our operating system.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
