import { ImageWithFallback } from '../figma/ImageWithFallback';

export function Slide14ClosingNew() {
  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Charcoal Background */}
      <div className="absolute inset-0 bg-[#2F2F2F]"></div>

      {/* Content */}
      <div className="relative h-full flex flex-col items-center justify-center px-8 md:px-16 lg:px-24 py-16">
        <div className="text-center">
          <h1 className="font-['Outfit'] text-6xl md:text-7xl lg:text-8xl leading-[0.95] text-white mb-8 tracking-tight">
            FOOTFALL LIMITED
          </h1>
          
          <div className="h-1 w-24 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mx-auto mb-10"></div>
          
          <p className="font-['Outfit'] text-3xl md:text-4xl text-[#A9DFF7] mb-16">
            Thank You
          </p>
          
          <div className="w-24 h-px bg-[#6EC1E4] mx-auto mb-12"></div>
          
          <p className="font-['Inter'] text-xl md:text-2xl text-white">
            hello@footfall.services
          </p>
          
          {/* Logo - Centered Below Email */}
          <div className="mt-12 flex justify-center">
            <ImageWithFallback
              src="https://6930b751d111c4417997a423.imgix.net/Footfall%20Logo%20white%20Text%20Transparent.png?w=169&h=246&rect=174%2C52%2C169%2C246"
              alt="Footfall Limited Logo"
              className="h-28 md:h-32 w-auto"
            />
          </div>
        </div>
      </div>
    </div>
  );
}