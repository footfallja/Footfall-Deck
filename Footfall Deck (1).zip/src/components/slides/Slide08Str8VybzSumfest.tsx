export function Slide08Str8VybzSumfest() {
  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1722570014465-9cdf5839778f?w=1920&auto=format&q=75"
          alt="Concert stage crowd"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
        <div className="absolute inset-0 bg-[#2F2F2F]/80"></div>
      </div>

      {/* Content - Asymmetric right alignment */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center items-end">
        <div className="max-w-[700px] text-right">
          <div className="text-sm font-['Inter'] text-[#6EC1E4] mb-2">CASE STUDY</div>
          <h2 className="font-['Outfit'] text-4xl md:text-5xl lg:text-6xl leading-[0.95] text-white mb-3">
            STR8 VYBZ:<br />Sumfest
          </h2>
          <p className="font-['Inter'] text-lg text-[#A9DFF7] mb-10">
            Thousands in Attendance • High-Pressure Night
          </p>

          <div className="space-y-6 mb-8 text-left">
            <div>
              <h4 className="font-['Outfit'] text-lg text-white mb-2">Owned</h4>
              <p className="font-['Inter'] text-base text-[#A9DFF7] leading-relaxed">
                14-person team • Sales push • Content • Navigation • Safety
              </p>
            </div>

            <div>
              <h4 className="font-['Outfit'] text-lg text-white mb-2">Reality</h4>
              <p className="font-['Inter'] text-base text-[#A9DFF7] leading-relaxed">
                Dense crowd • Night fatigue • Stampede/safety risk
              </p>
            </div>

            <div>
              <h4 className="font-['Outfit'] text-lg text-white mb-2">Delivered</h4>
              <p className="font-['Inter'] text-base text-[#A9DFF7] leading-relaxed">
                80+ bottle influence • Zero injuries • Rotated crews • Brand protected
              </p>
            </div>
          </div>

          <div className="pt-6 border-t border-[#6EC1E4] text-left">
            <p className="font-['Outfit'] text-xl text-white">
              Core Strength: <span className="text-[#6EC1E4]">Pressure management.</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}