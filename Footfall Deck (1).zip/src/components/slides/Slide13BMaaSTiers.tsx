export function Slide13BMaaSTiers() {
  const tiers = [
    {
      name: 'STARTER',
      activations: '2 activations/month',
      price: 'JMD $250k–$350k',
      description: 'Perfect for testing the market or seasonal campaigns',
      features: ['Monthly strategic planning', 'Field team coordination', 'Basic reporting']
    },
    {
      name: 'CORE',
      activations: '4 activations/month',
      price: 'JMD $400k–$700k',
      description: 'Ideal for consistent brand presence',
      features: ['Bi-weekly strategic planning', 'Priority field supervision', 'Advanced analytics', 'Pulse360 access (coming soon)'],
      highlight: true,
      badge: 'Most Popular'
    },
    {
      name: 'FULL COVERAGE',
      activations: '6–8 activations/month',
      price: 'JMD $750k–$1.2M+',
      description: 'Maximum market penetration',
      features: ['Weekly strategic sessions', 'Dedicated account manager', 'Real-time dashboards', 'Custom reporting']
    }
  ];

  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-[#FAFAFA] flex items-center px-8 md:px-16 lg:px-20 py-16 overflow-y-auto">
      <div className="w-full max-w-[1400px] mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-4">
            Flexible Pricing
          </span>
          <h2 className="font-['Outfit'] text-[40px] md:text-[48px] lg:text-[56px] leading-[1.05] text-[#2F2F2F] tracking-tight mb-4">
            BMaaS Tiers
          </h2>
          <p className="font-['Inter'] text-base md:text-lg text-[#4A5C6A]">
            Retainer covers management · Execution billed separately based on scope
          </p>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 mb-8">
          {tiers.map((tier, index) => (
            <div
              key={index}
              className={`relative rounded-2xl overflow-hidden transition-all ${
                tier.highlight
                  ? 'bg-[#6EC1E4] text-white scale-105 lg:scale-110 shadow-2xl'
                  : 'bg-white text-[#2F2F2F] hover:shadow-xl'
              }`}
            >
              {/* Badge */}
              {tier.badge && (
                <div className="absolute top-4 right-4">
                  <div className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full">
                    <span className="font-['Inter'] text-xs text-white uppercase tracking-wide">
                      {tier.badge}
                    </span>
                  </div>
                </div>
              )}

              <div className="p-8">
                {/* Tier Name */}
                <h3 className={`font-['Outfit'] text-xl mb-2 ${
                  tier.highlight ? 'text-white' : 'text-[#6EC1E4]'
                }`}>
                  {tier.name}
                </h3>

                {/* Description */}
                <p className={`font-['Inter'] text-sm mb-6 ${
                  tier.highlight ? 'text-white/80' : 'text-[#4A5C6A]'
                }`}>
                  {tier.description}
                </p>

                {/* Activations */}
                <div className="mb-6 pb-6 border-b border-current opacity-20">
                  <p className={`font-['Inter'] text-base ${
                    tier.highlight ? 'text-white' : 'text-[#2F2F2F]'
                  }`}>
                    {tier.activations}
                  </p>
                </div>

                {/* Price */}
                <div className="mb-8">
                  <p className={`font-['Outfit'] text-3xl ${
                    tier.highlight ? 'text-white' : 'text-[#2F2F2F]'
                  }`}>
                    {tier.price}
                  </p>
                  <p className={`font-['Inter'] text-xs mt-1 ${
                    tier.highlight ? 'text-white/60' : 'text-[#4A5C6A]'
                  }`}>
                    per month retainer
                  </p>
                </div>

                {/* Features */}
                <ul className="space-y-3">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <div className={`flex-shrink-0 w-1.5 h-1.5 rounded-full mt-2 ${
                        tier.highlight ? 'bg-white' : 'bg-[#6EC1E4]'
                      }`}></div>
                      <span className={`font-['Inter'] text-sm leading-relaxed ${
                        tier.highlight ? 'text-white/90' : 'text-[#4A5C6A]'
                      }`}>
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Footer Note */}
        <div className="text-center pt-6 border-t border-[#E5E5E5] max-w-[800px] mx-auto">
          <p className="font-['Inter'] text-sm text-[#4A5C6A] leading-relaxed">
            All tiers include strategic planning, field supervision, and reporting. 
            Execution costs are calculated per activation based on scope, store count, and materials.
          </p>
        </div>

      </div>
    </div>
  );
}
