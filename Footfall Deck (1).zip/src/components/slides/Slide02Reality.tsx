export function Slide02Reality() {
  const problems = [
    'Reports get dressed up',
    'Merchandising without real-time data',
    'Displays collapse',
    'Pricing drifts',
    'No one supervises',
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-white flex">
      {/* Left Content - 60% */}
      <div className="w-full lg:w-[60%] px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
        <div className="mb-12">
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-[#2F2F2F] mb-6">
            The Reality<br />in Retail
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <div className="space-y-5">
          {problems.map((problem, index) => (
            <div key={index} className="flex items-start gap-4">
              <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-3 flex-shrink-0"></div>
              <span className="font-['Inter'] text-xl md:text-2xl text-[#2F2F2F] leading-relaxed">
                {problem}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Right Image - 40% */}
      <div className="hidden lg:block w-[40%] relative">
        <img
          src="https://images.unsplash.com/photo-1606824722920-4c652a70f348?w=1200&auto=format&q=75"
          alt="Retail shelf"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
      </div>
    </div>
  );
}