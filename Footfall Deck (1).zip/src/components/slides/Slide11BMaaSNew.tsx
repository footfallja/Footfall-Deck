export function Slide11BMaaSNew() {
  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-gradient-to-br from-[#6EC1E4] to-[#4A5C6A] relative overflow-hidden flex items-center justify-center">
      
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 left-1/3 w-64 h-64 border-2 border-white rounded-full"></div>
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 border border-white rounded-full"></div>
          <div className="absolute top-1/2 left-1/2 w-32 h-32 border-2 border-white rounded-full"></div>
        </div>
      </div>

      <div className="relative px-8 md:px-16 lg:px-24 py-16 text-center max-w-[1000px]">
        
        {/* Label */}
        <div className="mb-8">
          <div className="inline-block px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full">
            <span className="font-['Inter'] text-xs uppercase tracking-widest text-white">
              Introducing
            </span>
          </div>
        </div>

        {/* Main Title */}
        <h2 className="font-['Outfit'] text-[48px] md:text-[64px] lg:text-[80px] xl:text-[96px] leading-[0.95] text-white tracking-tight mb-8">
          BMaaS
        </h2>

        {/* Subtitle */}
        <p className="font-['Outfit'] text-2xl md:text-3xl lg:text-4xl text-white/90 mb-12">
          Brand Manager as a Service
        </p>

        {/* Main Message */}
        <div className="max-w-[700px] mx-auto mb-12">
          <p className="font-['Inter'] text-xl md:text-2xl text-white leading-relaxed mb-6">
            Execution fails when no one owns it.
          </p>
          <p className="font-['Inter'] text-xl md:text-2xl text-white/90 leading-relaxed">
            BMaaS puts someone in the field who does.
          </p>
        </div>

        {/* Secondary Message */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-12">
          <p className="font-['Outfit'] text-2xl md:text-3xl text-white leading-tight mb-6">
            You lead the brand.<br />
            We make the work happen.
          </p>
          <p className="font-['Inter'] text-lg text-white/80 leading-relaxed">
            Pulse360 will soon give you a real-time window into every shift, in every space.
          </p>
        </div>

        {/* Bottom Line */}
        <div className="flex items-center justify-center gap-4">
          <div className="hidden md:block w-16 h-px bg-white"></div>
          <div>
            <p className="font-['Outfit'] text-xl md:text-2xl text-white">
              BMaaS isn't oversight.<br />
              <span className="text-[#2F2F2F]">It's control.</span>
            </p>
          </div>
          <div className="hidden md:block w-16 h-px bg-white"></div>
        </div>

      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white to-transparent"></div>
    </div>
  );
}
