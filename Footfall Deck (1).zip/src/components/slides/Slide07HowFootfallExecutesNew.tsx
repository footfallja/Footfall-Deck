import { ArrowRight } from 'lucide-react';

export function Slide07HowFootfallExecutesNew() {
  const steps = ['Plan', 'Deploy', 'Execute', 'Verify', 'Report'];

  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#4A5C6A] to-[#2F2F2F]"></div>

      {/* Background Image */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src="https://6930b751d111c4417997a423.imgix.net/slide%207.2.png"
          alt="Supervisor verifying execution"
          className="w-full h-full object-contain"
          loading="eager"
          decoding="async"
        />
      </div>

      {/* Content */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-between">
        <div>
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
            How Footfall<br />Executes
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-16"></div>

          {/* Process flow */}
          <div className="flex flex-wrap items-center gap-4 mb-20">
            {steps.map((step, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="px-6 py-3 bg-[#6EC1E4] rounded-full">
                  <span className="font-['Outfit'] text-xl text-white">{step}</span>
                </div>
                {index < steps.length - 1 && (
                  <ArrowRight className="w-6 h-6 text-[#A9DFF7]" />
                )}
              </div>
            ))}
          </div>

          <div className="space-y-4 mb-12">
            <p className="font-['Inter'] text-xl md:text-2xl text-[#A9DFF7] leading-relaxed">
              Every shift supervised.
            </p>
            <p className="font-['Inter'] text-xl md:text-2xl text-[#A9DFF7] leading-relaxed">
              Every touchpoint documented.
            </p>
            <p className="font-['Inter'] text-xl md:text-2xl text-[#A9DFF7] leading-relaxed">
              Every issue solved before it reaches you.
            </p>
          </div>
        </div>

        {/* Pulse360 callout */}
        <div className="max-w-[700px] p-8 border-l-4 border-[#6EC1E4] bg-[#2F2F2F]/50">
          <p className="font-['Inter'] text-lg md:text-xl text-[#A9DFF7] leading-relaxed">
            <span className="text-white font-['Outfit']">Pulse360 (Coming):</span> Real-time attendance, photos, tasks, and trade-space intelligence.
          </p>
        </div>
      </div>
    </div>
  );
}