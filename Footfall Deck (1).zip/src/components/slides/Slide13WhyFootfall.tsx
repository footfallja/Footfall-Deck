export function Slide13WhyFootfall() {
  const reasons = [
    'Execution without excuses.',
    'Structure where brands need it.',
    'Control where trade breaks.',
    'Data instead of guesswork.',
    'Teams that don\'t fall apart.',
    'Your brand — properly executed.'
  ];

  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Subtle geometric background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-[#6EC1E4] rounded-full"></div>
      </div>

      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px] flex items-center">
        <div className="w-full">
          
          {/* Header */}
          <div className="mb-16">
            <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-6">
              WHY CHOOSE US
            </p>
            <h2 className="font-['Outfit'] text-[64px] leading-[1.05] text-white">
              Why Footfall
            </h2>
          </div>

          {/* Reasons */}
          <div className="grid grid-cols-2 gap-x-24 gap-y-10 max-w-[1000px]">
            {reasons.map((reason, index) => (
              <div key={index} className="flex items-start gap-6">
                <div className="w-10 h-10 rounded-full bg-[#6EC1E4] flex items-center justify-center flex-shrink-0">
                  <span className="font-['Outfit'] text-[16px] text-[#2F2F2F]">
                    {index + 1}
                  </span>
                </div>
                <p className="font-['Inter'] text-[20px] text-white leading-relaxed pt-1">
                  {reason}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
