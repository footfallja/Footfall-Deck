export function Slide06Str8VybzCarnival() {
  return (
    <div className="w-full h-full min-h-[600px] bg-white flex flex-col lg:flex-row">
      {/* Left Image - 50% */}
      <div className="w-full lg:w-[50%] h-[300px] lg:h-full relative">
        <img
          src="https://images.unsplash.com/photo-1659895416894-6c5ab7fd597c?w=1200&auto=format&q=75"
          alt="Carnival festival"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
      </div>

      {/* Right Content - 50% */}
      <div className="w-full lg:w-[50%] px-8 md:px-16 lg:px-20 py-12 md:py-16 lg:py-20 flex flex-col justify-center bg-[#F8F8F8]">
        <div className="mb-6">
          <div className="text-sm font-['Inter'] text-[#6EC1E4] mb-2">CASE STUDY</div>
          <h2 className="font-['Outfit'] text-4xl md:text-5xl leading-[0.95] text-[#2F2F2F] mb-3">
            STR8 VYBZ: Fever Punch<br />Carnival Launch
          </h2>
          <p className="font-['Inter'] text-lg text-[#4A5C6A]">
            4 Events • 4 Days • Multi-Environment Execution
          </p>
        </div>

        <div className="space-y-6 mb-8">
          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Owned</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Experience zone • Sampling • Team mgmt • Dancers • Content
            </p>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Reality</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Crowds • Heat • Fatigue • Long hours
            </p>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Delivered</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Clean resets • Fast fixes • Stock discipline • Teams that lasted • Full multi-day control
            </p>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Results</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Feature in the Jamaica Star - Carnival Chronicles<br />
              Coverage on social media
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-[#6EC1E4]">
          <p className="font-['Outfit'] text-xl text-[#2F2F2F]">
            Core Strength: <span className="text-[#6EC1E4]">Operational stamina.</span>
          </p>
        </div>
      </div>
    </div>
  );
}