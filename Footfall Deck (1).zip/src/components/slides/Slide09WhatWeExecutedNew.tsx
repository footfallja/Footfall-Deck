export function Slide09WhatWeExecutedNew() {
  const operations = [
    'Large-scale event operations',
    'National mobile activations',
    'Multi-location sampling',
    'Trade-space merchandising',
    'Community-level engagement programs',
    'Product introduction rollouts',
    'Industrial and agricultural support operations'
  ];

  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#4A5C6A] to-[#2F2F2F]"></div>

      {/* Subtle accent */}
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] border border-[#6EC1E4] opacity-5 rounded-full -translate-x-1/2 translate-y-1/2"></div>

      {/* Content */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
        <div className="mb-16">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
            What We've Executed
          </span>
          <h2 className="font-['Outfit'] text-5xl md:text-6xl lg:text-7xl leading-[0.95] text-white mb-6">
            Our operational<br />background includes:
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-x-16 gap-y-5 mb-12 max-w-[1000px]">
          {operations.map((op, index) => (
            <div key={index} className="flex items-start gap-4">
              <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-3 flex-shrink-0"></div>
              <span className="font-['Inter'] text-xl md:text-2xl text-[#A9DFF7] leading-relaxed">
                {op}
              </span>
            </div>
          ))}
        </div>

        <div className="max-w-[800px] p-8 border-l-4 border-[#6EC1E4] bg-[#2F2F2F]/50">
          <p className="font-['Inter'] text-xl md:text-2xl text-white leading-relaxed mb-3">
            We understand environments with pressure, variability, and moving parts.
          </p>
          <p className="font-['Outfit'] text-2xl md:text-3xl text-[#6EC1E4] leading-tight">
            Our processes come from real field experience.
          </p>
        </div>
      </div>
    </div>
  );
}
