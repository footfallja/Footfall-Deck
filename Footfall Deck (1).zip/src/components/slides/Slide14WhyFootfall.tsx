export function Slide14WhyFootfall() {
  const reasons = [
    {
      title: 'Execution without excuses',
      description: 'We deliver what we promise, when we promise it.'
    },
    {
      title: 'Structure where brands need it',
      description: 'Professional field operations in a fragmented market.'
    },
    {
      title: 'Control where retail breaks',
      description: 'Visibility and compliance at every touchpoint.'
    },
    {
      title: 'Data instead of guesswork',
      description: 'Store-level insights drive smarter decisions.'
    },
    {
      title: 'Teams that don\'t fall apart',
      description: 'Consistent, trained professionals representing your brand.'
    },
    {
      title: 'Your brand — properly executed',
      description: 'Every detail matters. Every store counts.'
    }
  ];

  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-white flex items-center px-8 md:px-16 lg:px-24 xl:px-32 py-16">
      <div className="w-full max-w-[1200px] mx-auto">
        
        {/* Header */}
        <div className="mb-16">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
            Why Choose Us
          </span>
          <h2 className="font-['Outfit'] text-[40px] md:text-[52px] lg:text-[64px] leading-[1.05] text-[#2F2F2F] tracking-tight">
            Why Footfall
          </h2>
        </div>

        {/* Reasons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
          {reasons.map((reason, index) => (
            <div 
              key={index}
              className="group flex items-start gap-6 p-6 rounded-xl hover:bg-[#FAFAFA] transition-all"
            >
              {/* Number */}
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-[#6EC1E4] flex items-center justify-center group-hover:scale-110 transition-transform">
                  <span className="font-['Outfit'] text-sm text-white">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 pt-1">
                <h3 className="font-['Outfit'] text-xl md:text-2xl text-[#2F2F2F] mb-2 leading-tight">
                  {reason.title}
                </h3>
                <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
                  {reason.description}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}