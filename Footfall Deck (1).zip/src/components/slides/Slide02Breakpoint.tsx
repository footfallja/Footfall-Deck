export function Slide02Breakpoint() {
  return (
    <div className="w-full aspect-[16/9] bg-white relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1760306612945-47447bc54bd1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXRhaWwlMjBkaXNwbGF5JTIwY29udHJhc3R8ZW58MXx8fHwxNzY1NDI4NDgyfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Contrast in retail execution"
          className="w-full h-full object-cover opacity-25"
        />
      </div>

      {/* Content - Asymmetric Layout */}
      <div className="relative h-full flex items-center px-[120px]">
        <div className="max-w-[700px] ml-auto">
          <h2 className="font-['Outfit'] text-[64px] leading-[1.1] tracking-tight text-[#2F2F2F]">
            Trade marketing doesn't fail in strategy.
          </h2>
          <h2 className="font-['Outfit'] text-[64px] leading-[1.1] tracking-tight text-[#6EC1E4] mt-4">
            It fails in execution.
          </h2>
        </div>
      </div>
    </div>
  );
}
