export function Slide04JamaicanRealityNew() {
  return (
    <div className="w-full h-full min-h-[600px] bg-white flex">
      {/* Left Content - 60% */}
      <div className="w-full lg:w-[60%] px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
        <div className="mb-12">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
            The Jamaican Trade Reality
          </span>
          <h2 className="font-['Outfit'] text-4xl md:text-5xl lg:text-6xl leading-[1.05] text-[#2F2F2F] mb-6">
            Jamaica's trade environment is uneven and unpredictable.
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <p className="font-['Inter'] text-xl md:text-2xl text-[#4A5C6A] leading-relaxed mb-10">
          A significant share of consumption moves through informal and semi-formal spaces, shaped by different behaviours, income levels, and expectations.
        </p>

        <div className="space-y-4 mb-10">
          <p className="font-['Inter'] text-xl md:text-2xl text-[#2F2F2F]">
            Standards fluctuate.
          </p>
          <p className="font-['Inter'] text-xl md:text-2xl text-[#2F2F2F]">
            Consumer decisions shift.
          </p>
          <p className="font-['Inter'] text-xl md:text-2xl text-[#2F2F2F]">
            Conditions change without warning.
          </p>
        </div>

        <div className="p-6 border-l-4 border-[#6EC1E4] bg-[#FAFAFA]">
          <p className="font-['Outfit'] text-xl md:text-2xl text-[#2F2F2F] leading-tight">
            Effective trade execution must absorb this variability, not wait for perfect conditions.
          </p>
        </div>

        <p className="font-['Inter'] text-sm text-[#4A5C6A] italic mt-8">
          Source: Jamaican consumer & trade environment reporting.
        </p>
      </div>

      {/* Right Image - 40% */}
      <div className="hidden lg:block w-[40%] relative">
        <img
          src="https://6930b751d111c4417997a423.imgix.net/slide%204.3.png"
          alt="Jamaican trade environments"
          className="w-full h-full object-contain"
          loading="eager"
          decoding="async"
        />
      </div>
    </div>
  );
}