export function Slide08OurExperienceNew() {
  const experiences = [
    'Executed high-pressure event operations',
    'Managed multi-day field activations',
    'Delivered national sampling programs',
    'Directed merchandising across trade spaces',
    'Run mobile and logistics-heavy programs',
    'Supervised large, rotating field teams',
    'Solved issues in real time under changing conditions'
  ];

  return (
    <div className="w-full h-full min-h-[600px] bg-white flex">
      {/* Left Image - 40% */}
      <div className="hidden lg:block w-[40%] relative">
        <img
          src="https://6930b751d111c4417997a423.imgix.net/team%201.png"
          alt="Field teams at work"
          className="w-full h-full object-contain"
          loading="eager"
          decoding="async"
        />
      </div>

      {/* Right Content - 60% */}
      <div className="w-full lg:w-[60%] px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center">
        <div className="mb-12">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4] mb-6">
            Our Experience
          </span>
          <h2 className="font-['Outfit'] text-4xl md:text-5xl lg:text-6xl leading-[1.05] text-[#2F2F2F] mb-6">
            Our team has years of operational experience across Jamaica's trade landscape.
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <p className="font-['Inter'] text-xl md:text-2xl text-[#4A5C6A] mb-8">
          We have:
        </p>

        <div className="space-y-4 mb-12">
          {experiences.map((exp, index) => (
            <div key={index} className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-3 flex-shrink-0"></div>
              <span className="font-['Inter'] text-lg md:text-xl text-[#2F2F2F] leading-relaxed">
                {exp}
              </span>
            </div>
          ))}
        </div>

        <div className="p-6 border-l-4 border-[#6EC1E4] bg-[#FAFAFA]">
          <p className="font-['Outfit'] text-xl md:text-2xl text-[#2F2F2F] leading-tight mb-2">
            We've done the work —
          </p>
          <p className="font-['Inter'] text-lg text-[#4A5C6A] mb-3">
            the systems, the pressure, the unpredictability.
          </p>
          <p className="font-['Outfit'] text-xl md:text-2xl text-[#6EC1E4] leading-tight">
            Footfall is built on that experience.
          </p>
        </div>
      </div>
    </div>
  );
}