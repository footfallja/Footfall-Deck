export function Slide09WhatWeExecuted() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Subtle accent */}
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] border border-[#6EC1E4] opacity-5 rounded-full -translate-x-1/2 translate-y-1/2"></div>

      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px] flex items-center">
        <div className="grid grid-cols-12 gap-[24px] w-full">
          
          <div className="col-span-11">
            <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-8">
              WHAT WE'VE EXECUTED
            </p>

            <h2 className="font-['Outfit'] text-[44px] leading-[1.15] text-white mb-12 max-w-[700px]">
              Our operational background includes:
            </h2>

            <div className="grid grid-cols-2 gap-x-16 gap-y-6 mb-12">
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>Large-scale event operations</span>
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>National mobile activations</span>
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>Multi-location sampling</span>
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>Trade-space merchandising</span>
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>Community-level engagement programs</span>
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>Product introduction rollouts</span>
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] flex items-start col-span-2">
                <span className="text-[#6EC1E4] mr-4">•</span>
                <span>Industrial and agricultural support operations</span>
              </p>
            </div>

            <div className="max-w-[800px] mt-16">
              <p className="font-['Inter'] text-[20px] text-white leading-relaxed mb-4">
                We understand environments with pressure, variability, and moving parts.
              </p>
              <p className="font-['Outfit'] text-[28px] text-[#6EC1E4] leading-tight">
                Our processes come from real field experience.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
