import { ArrowLeft, Grid3x3, Type, Palette, Box } from 'lucide-react';

interface BrandSystemProps {
  onBack: () => void;
}

export function BrandSystem({ onBack }: BrandSystemProps) {
  const colors = [
    { name: 'Footfall / SkyBlue', hex: '#6EC1E4', style: 'bg-[#6EC1E4]' },
    { name: 'Footfall / SkyBlueGlow', hex: '#A9DFF7', style: 'bg-[#A9DFF7]' },
    { name: 'Footfall / Charcoal', hex: '#2F2F2F', style: 'bg-[#2F2F2F]' },
    { name: 'Footfall / SlateGray', hex: '#4A5C6A', style: 'bg-[#4A5C6A]' },
    { name: 'Footfall / White', hex: '#FFFFFF', style: 'bg-white border border-gray-300' },
  ];

  const overlays = [
    { name: 'Overlay / Charcoal70', hex: '#2F2F2F at 70%', style: 'bg-[#2F2F2F] opacity-70' },
    { name: 'Overlay / SkyBlue40', hex: '#6EC1E4 at 40%', style: 'bg-[#6EC1E4] opacity-40' },
  ];

  return (
    <div className="min-h-screen bg-white overflow-auto">
      {/* Header */}
      <div className="bg-[#2F2F2F] text-white p-8">
        <button
          onClick={onBack}
          className="flex items-center text-[#6EC1E4] hover:text-[#A9DFF7] mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Home
        </button>
        <h1 className="text-[#6EC1E4] mb-2">FOOTFALL LIMITED</h1>
        <p className="text-[#A9DFF7]">Complete Brand System</p>
      </div>

      <div className="max-w-7xl mx-auto p-12">
        {/* Color Styles */}
        <section className="mb-16">
          <div className="flex items-center mb-8">
            <Palette className="w-8 h-8 text-[#6EC1E4] mr-3" />
            <h2 className="text-[#2F2F2F]">Color Styles</h2>
          </div>
          
          <div className="grid md:grid-cols-5 gap-6 mb-8">
            {colors.map((color) => (
              <div key={color.name} className="space-y-3">
                <div className={`${color.style} h-32 rounded-lg shadow-md`}></div>
                <div>
                  <p className="text-[#2F2F2F]">{color.name.split(' / ')[1]}</p>
                  <p className="text-[#4A5C6A] text-sm">{color.hex}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-5 gap-6">
            {overlays.map((overlay) => (
              <div key={overlay.name} className="space-y-3">
                <div className="relative h-32 rounded-lg overflow-hidden shadow-md bg-white">
                  <div className={`${overlay.style} w-full h-full`}></div>
                </div>
                <div>
                  <p className="text-[#2F2F2F]">{overlay.name.split(' / ')[1]}</p>
                  <p className="text-[#4A5C6A] text-sm">{overlay.hex}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Typography Styles */}
        <section className="mb-16">
          <div className="flex items-center mb-8">
            <Type className="w-8 h-8 text-[#6EC1E4] mr-3" />
            <h2 className="text-[#2F2F2F]">Typography Styles</h2>
          </div>

          <div className="space-y-8">
            <div>
              <p className="text-[#4A5C6A] mb-4">Outfit Bold</p>
              <div className="space-y-4">
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">H1 / 80px</span>
                  <span className="font-['Outfit'] text-[80px] leading-none text-[#2F2F2F]">Footfall</span>
                </div>
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">H2 / 60px</span>
                  <span className="font-['Outfit'] text-[60px] leading-none text-[#2F2F2F]">Trade Marketing</span>
                </div>
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">H3 / 40px</span>
                  <span className="font-['Outfit'] text-[40px] leading-none text-[#2F2F2F]">Real Execution</span>
                </div>
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">H4 / 28px</span>
                  <span className="font-['Outfit'] text-[28px] leading-none text-[#2F2F2F]">Field Teams</span>
                </div>
              </div>
            </div>

            <div>
              <p className="text-[#4A5C6A] mb-4">Inter Regular</p>
              <div className="space-y-4">
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">Body / 26px</span>
                  <span className="font-['Inter'] text-[26px] text-[#2F2F2F]">Primary body text</span>
                </div>
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">Body / 22px</span>
                  <span className="font-['Inter'] text-[22px] text-[#2F2F2F]">Secondary body text</span>
                </div>
                <div className="flex items-baseline gap-8">
                  <span className="text-[#4A5C6A] w-24 text-sm">Body / 18px</span>
                  <span className="font-['Inter'] text-[18px] text-[#2F2F2F]">Tertiary body text</span>
                </div>
              </div>
            </div>

            <div>
              <p className="text-[#4A5C6A] mb-4">Inter Light</p>
              <div className="flex items-baseline gap-8">
                <span className="text-[#4A5C6A] w-24 text-sm">Caption / 16px</span>
                <span className="font-['Inter'] font-light text-[16px] text-[#2F2F2F]">Caption text</span>
              </div>
            </div>
          </div>
        </section>

        {/* Grid System */}
        <section className="mb-16">
          <div className="flex items-center mb-8">
            <Grid3x3 className="w-8 h-8 text-[#6EC1E4] mr-3" />
            <h2 className="text-[#2F2F2F]">Grid System (1920×1080)</h2>
          </div>

          <div className="bg-[#4A5C6A] p-8 rounded-lg text-white space-y-4">
            <div className="flex justify-between">
              <span>Columns:</span>
              <span>12</span>
            </div>
            <div className="flex justify-between">
              <span>Margins:</span>
              <span>120px</span>
            </div>
            <div className="flex justify-between">
              <span>Gutters:</span>
              <span>24px</span>
            </div>
            <div className="flex justify-between">
              <span>Vertical Spacing:</span>
              <span>80px</span>
            </div>
          </div>
        </section>

        {/* Component Library */}
        <section>
          <div className="flex items-center mb-8">
            <Box className="w-8 h-8 text-[#6EC1E4] mr-3" />
            <h2 className="text-[#2F2F2F]">Component Library</h2>
          </div>

          <div className="space-y-8">
            {/* Title Block */}
            <div className="border-2 border-[#6EC1E4] rounded-xl p-8">
              <p className="text-[#4A5C6A] mb-4">1. Title Block</p>
              <div>
                <h1 className="font-['Outfit'] text-[80px] leading-none text-[#2F2F2F] mb-3">Title</h1>
                <div className="h-1 w-[120px] bg-[#6EC1E4] mb-3"></div>
                <h3 className="font-['Outfit'] text-[40px] leading-none text-[#4A5C6A]">Optional Subtitle</h3>
              </div>
            </div>

            {/* Bullet List */}
            <div className="border-2 border-[#6EC1E4] rounded-xl p-8">
              <p className="text-[#4A5C6A] mb-4">2. Bullet List</p>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-2.5"></div>
                  <span className="font-['Inter'] text-[22px] text-[#2F2F2F]">Bullet point item</span>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#6EC1E4] mt-2.5"></div>
                  <span className="font-['Inter'] text-[22px] text-[#2F2F2F]">Bullet point item</span>
                </div>
              </div>
            </div>

            {/* Service Block */}
            <div className="border-2 border-[#6EC1E4] rounded-xl p-8">
              <p className="text-[#4A5C6A] mb-4">3. Service Block</p>
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#6EC1E4] flex items-center justify-center flex-shrink-0">
                  <Box className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-['Outfit'] text-[28px] leading-none text-[#2F2F2F] mb-2">Service Name</h4>
                  <p className="font-['Inter'] text-[18px] text-[#4A5C6A]">Service description text</p>
                </div>
              </div>
            </div>

            {/* Process Step Block */}
            <div className="border-2 border-[#6EC1E4] rounded-xl p-8">
              <p className="text-[#4A5C6A] mb-4">4. Process Step Block</p>
              <div className="bg-white border-2 border-[#A9DFF7] rounded-2xl p-6">
                <h4 className="font-['Outfit'] text-[28px] leading-none text-[#2F2F2F] mb-2">Step Name</h4>
                <p className="font-['Inter'] text-[18px] text-[#4A5C6A]">Step description</p>
              </div>
            </div>

            {/* Engagement Card */}
            <div className="border-2 border-[#6EC1E4] rounded-xl p-8">
              <p className="text-[#4A5C6A] mb-4">5. Engagement Card</p>
              <div className="bg-white border-2 border-[#6EC1E4] rounded-3xl p-6 shadow-lg">
                <h4 className="font-['Outfit'] text-[28px] leading-none text-[#2F2F2F] mb-2">Card Title</h4>
                <p className="font-['Inter'] text-[18px] text-[#4A5C6A]">Card content</p>
              </div>
            </div>

            {/* Divider Line */}
            <div className="border-2 border-[#6EC1E4] rounded-xl p-8">
              <p className="text-[#4A5C6A] mb-4">7. Divider Line</p>
              <div className="h-1 w-[120px] bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
