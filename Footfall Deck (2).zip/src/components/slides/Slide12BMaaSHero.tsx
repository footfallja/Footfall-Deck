export function Slide12BMaaSHero() {
  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-gradient-to-br from-[#6EC1E4] to-[#4A5C6A] relative overflow-hidden flex items-center justify-center">
      
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 left-1/3 w-64 h-64 border-2 border-white rounded-full"></div>
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 border border-white rounded-full"></div>
          <div className="absolute top-1/2 left-1/2 w-32 h-32 border-2 border-white rounded-full"></div>
        </div>
      </div>

      <div className="relative px-8 md:px-16 lg:px-24 py-16 text-center max-w-[1000px]">
        
        {/* Label */}
        <div className="mb-8">
          <div className="inline-block px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full">
            <span className="font-['Inter'] text-xs uppercase tracking-widest text-white">
              Our Service Model
            </span>
          </div>
        </div>

        {/* Main Title */}
        <h2 className="font-['Outfit'] text-[48px] md:text-[64px] lg:text-[80px] xl:text-[96px] leading-[0.95] text-white tracking-tight mb-8">
          BMaaS
        </h2>

        {/* Subtitle */}
        <p className="font-['Outfit'] text-2xl md:text-3xl lg:text-4xl text-white/90 mb-6">
          Brand Manager as a Service
        </p>

        {/* Description */}
        <p className="font-['Inter'] text-lg md:text-xl text-white/80 leading-relaxed max-w-[700px] mx-auto mb-12">
          Flexible retainer-based trade marketing management. You get strategic oversight, field operations, and execution — without hiring full-time staff.
        </p>

        {/* Value Props */}
        <div className="flex flex-wrap items-center justify-center gap-6 md:gap-8">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-white"></div>
            <span className="font-['Inter'] text-sm md:text-base text-white">Strategic Planning</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-white"></div>
            <span className="font-['Inter'] text-sm md:text-base text-white">Field Supervision</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-white"></div>
            <span className="font-['Inter'] text-sm md:text-base text-white">Performance Reporting</span>
          </div>
        </div>

      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white to-transparent"></div>
    </div>
  );
}
