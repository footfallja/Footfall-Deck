export function Slide05TheGap() {
  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-[#2F2F2F] relative overflow-hidden flex items-center justify-center">
      
      {/* Geometric Background Elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 border border-[#6EC1E4] rounded-full"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 border border-[#A9DFF7] rounded-full"></div>
      </div>

      <div className="relative px-8 md:px-16 lg:px-24 py-16 text-center max-w-[1000px]">
        
        {/* Label */}
        <div className="mb-12">
          <span className="inline-block font-['Inter'] text-xs uppercase tracking-widest text-[#6EC1E4]">
            The Opportunity
          </span>
        </div>

        {/* Main Statement */}
        <h2 className="font-['Outfit'] text-[36px] md:text-[48px] lg:text-[64px] xl:text-[72px] leading-[1.05] text-white tracking-tight mb-12">
          There's a gap between brand strategy and retail execution.
        </h2>

        {/* Secondary Statement */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <div className="hidden md:block w-24 h-px bg-[#6EC1E4]"></div>
          <p className="font-['Outfit'] text-2xl md:text-3xl lg:text-4xl text-[#6EC1E4]">
            Footfall fills it.
          </p>
          <div className="hidden md:block w-24 h-px bg-[#6EC1E4]"></div>
        </div>

        {/* Description */}
        <p className="font-['Inter'] text-lg md:text-xl text-[#A9DFF7] leading-relaxed max-w-[700px] mx-auto">
          We bridge the last mile between what brands plan and what actually happens in stores across Jamaica.
        </p>

      </div>
    </div>
  );
}
