export function Slide02BreakpointNew() {
  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-white relative overflow-hidden flex items-center justify-center">
      
      {/* Background Image */}
      <div className="absolute inset-0 opacity-15">
        <img 
          src="https://6930b751d111c4417997a423.imgix.net/slide2.png"
          alt="Retail contrast"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
      </div>

      <div className="relative px-8 md:px-16 lg:px-24 py-16 text-center max-w-[1100px]">
        <h2 className="font-['Outfit'] text-[42px] md:text-[56px] lg:text-[68px] leading-[1.05] text-[#2F2F2F] tracking-tight">
          Trade marketing doesn't fail in strategy.
        </h2>
        <div className="flex items-center justify-center my-10">
          <div className="h-px w-32 bg-[#6EC1E4]"></div>
        </div>
        <h2 className="font-['Outfit'] text-[42px] md:text-[56px] lg:text-[68px] leading-[1.05] text-[#6EC1E4] tracking-tight">
          It fails in execution.
        </h2>
      </div>
    </div>
  );
}