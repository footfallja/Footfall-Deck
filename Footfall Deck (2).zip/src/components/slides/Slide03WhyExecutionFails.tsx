export function Slide03WhyExecutionFails() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Content Grid */}
      <div className="relative h-full grid grid-cols-12 gap-[24px] px-[120px] py-[80px]">
        
        {/* Left Column - Global */}
        <div className="col-span-5">
          <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-6">
            GLOBAL REALITY
          </p>
          <h3 className="font-['Outfit'] text-[36px] leading-[1.15] text-white mb-8">
            Brands lose revenue when execution breaks:
          </h3>
          <ul className="space-y-4 mb-8">
            <li className="font-['Inter'] text-[18px] text-[#A9DFF7] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Visibility drops</span>
            </li>
            <li className="font-['Inter'] text-[18px] text-[#A9DFF7] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Displays collapse</span>
            </li>
            <li className="font-['Inter'] text-[18px] text-[#A9DFF7] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Activation plans fail</span>
            </li>
            <li className="font-['Inter'] text-[18px] text-[#A9DFF7] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Issues surface too late</span>
            </li>
          </ul>
          <p className="font-['Inter'] text-[14px] text-[#4A5C6A] italic">
            Source: NielsenIQ, McKinsey & global retail execution studies.
          </p>
        </div>

        {/* Spacer */}
        <div className="col-span-1"></div>

        {/* Right Column - Jamaica */}
        <div className="col-span-6">
          <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-6">
            JAMAICA REALITY
          </p>
          <h3 className="font-['Outfit'] text-[36px] leading-[1.15] text-white mb-8">
            In Jamaica, the gaps widen:
          </h3>
          <div className="space-y-6 mb-10">
            <p className="font-['Inter'] text-[18px] text-[#A9DFF7] leading-relaxed">
              Promoters create guesswork, not data.
            </p>
            <p className="font-['Inter'] text-[18px] text-[#A9DFF7] leading-relaxed">
              Trade activities aren't verified in real time.
            </p>
            <p className="font-['Inter'] text-[18px] text-[#A9DFF7] leading-relaxed">
              Reports get dressed up.
            </p>
            <p className="font-['Inter'] text-[18px] text-[#A9DFF7] leading-relaxed">
              No one supervises.
            </p>
          </div>
          <div className="border-l-4 border-[#6EC1E4] pl-6">
            <p className="font-['Outfit'] text-[28px] leading-tight text-white">
              This is the execution gap.
              <br />
              This is where brands lose money.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
