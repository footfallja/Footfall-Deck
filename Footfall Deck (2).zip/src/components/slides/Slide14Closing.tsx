export function Slide14Closing() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://images.unsplash.com/photo-1686030969145-6bf9f3155472?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwZ2VvbWV0cmljJTIwbGluZXN8ZW58MXx8fHwxNzY1NDI4NDgzfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Minimal geometric background"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Geometric Lines */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-[30%] w-px h-full bg-[#6EC1E4]"></div>
        <div className="absolute top-0 left-[70%] w-px h-full bg-[#6EC1E4]"></div>
        <div className="absolute top-[40%] left-0 w-full h-px bg-[#6EC1E4]"></div>
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col items-center justify-center px-[120px]">
        <div className="text-center">
          <h1 className="font-['Outfit'] text-[80px] leading-[1.05] text-white mb-6">
            FOOTFALL LIMITED
          </h1>
          
          <p className="font-['Outfit'] text-[32px] text-[#A9DFF7] mb-16">
            Thank You
          </p>
          
          <div className="w-24 h-px bg-[#6EC1E4] mx-auto mb-12"></div>
          
          <p className="font-['Inter'] text-[20px] text-white">
            hello@footfall.services
          </p>
        </div>
      </div>
    </div>
  );
}
