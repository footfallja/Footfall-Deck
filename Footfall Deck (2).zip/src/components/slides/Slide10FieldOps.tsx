export function Slide10FieldOps() {
  return (
    <div className="w-full h-full min-h-[600px] bg-white flex flex-col lg:flex-row">
      {/* Left Content - 55% */}
      <div className="w-full lg:w-[55%] px-8 md:px-16 lg:px-20 py-12 md:py-16 lg:py-20 flex flex-col justify-center">
        <div className="mb-10">
          <h2 className="font-['Outfit'] text-4xl md:text-5xl lg:text-6xl leading-[0.95] text-[#2F2F2F] mb-6">
            Field Teams<br />Beyond Retail
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7]"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-10">
          <div>
            <h4 className="font-['Outfit'] text-xl text-[#2F2F2F] mb-4">Projects</h4>
            <div className="space-y-2 font-['Inter'] text-base text-[#4A5C6A]">
              <p>Grand Gala 2024</p>
              <p>Marcia Griffiths & Friends</p>
              <p>Hurricane Beryl Relief Tour</p>
              <p>Warehouse ops</p>
            </div>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-xl text-[#2F2F2F] mb-4">Roles</h4>
            <div className="space-y-2 font-['Inter'] text-base text-[#4A5C6A]">
              <p>Setup & Pull-down crew</p>
              <p>Drivers/logistics</p>
            </div>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-xl text-[#2F2F2F] mb-4">Management</h4>
            <div className="space-y-2 font-['Inter'] text-base text-[#4A5C6A]">
              <p>Rotation</p>
              <p>Energy mgmt</p>
              <p>Safety</p>
              <p>Troubleshooting</p>
            </div>
          </div>

          <div className="flex items-end">
            <div className="p-6 bg-[#F8F8F8] border-l-4 border-[#6EC1E4]">
              <p className="font-['Outfit'] text-lg text-[#2F2F2F]">
                Outcome:<br />
                <span className="text-[#6EC1E4]">Crews that work efficient and don't collapse.</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Image - 45% */}
      <div className="w-full lg:w-[45%] h-[300px] lg:h-full relative">
        <img
          src="https://images.unsplash.com/photo-1761053703248-d578c6c09ab5?w=1200&auto=format&q=75"
          alt="Event crew"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
      </div>
    </div>
  );
}
