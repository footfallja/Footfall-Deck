export function Slide12BMaaS() {
  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1758518729263-e26fb50db6bc?w=1920&auto=format&q=75"
          alt="Team reviewing plan"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
        <div className="absolute inset-0 bg-[#2F2F2F]/80"></div>
      </div>

      {/* Content - Centered */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-center items-center text-center">
        <div className="max-w-[900px]">
          <div className="h-1 w-20 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-8 mx-auto"></div>
          
          <h2 className="font-['Outfit'] text-6xl md:text-7xl lg:text-8xl leading-[0.9] text-white mb-6">
            BMaaS
          </h2>
          
          <h3 className="font-['Outfit'] text-3xl md:text-4xl text-[#A9DFF7] mb-12">
            Brand Manager as a Service
          </h3>

          <p className="font-['Inter'] text-xl md:text-2xl text-white leading-relaxed mb-16 max-w-[700px] mx-auto">
            Trade marketing doesn’t fail in the plan. It fails in the execution. BMaaS puts someone in the field who owns the day-to-day: the teams, the stores, the fixes, the follow-through.
You drive the brand. We make sure the work actually happens.
          </p>

          <div className="p-8 bg-[#2F2F2F]/70 border border-[#6EC1E4] max-w-[700px] mx-auto">
            <p className="font-['Inter'] text-lg text-[#A9DFF7] leading-relaxed">
              BMaaS will integrate with <span className="text-white font-['Outfit']">Pulse360</span> once launched for clearer digital field visibility.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
