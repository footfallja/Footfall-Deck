import { ImageWithFallback } from '../figma/ImageWithFallback';

export function Slide01CoverNew() {
  return (
    <div className="relative w-full h-full min-h-[600px]">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://6930b751d111c4417997a423.imgix.net/slide%201%20girl.png"
          alt="Jamaican trade environment"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#2F2F2F]/90 to-[#4A5C6A]/80"></div>
      </div>

      {/* Content */}
      <div className="relative h-full px-8 md:px-16 lg:px-[120px] py-16 md:py-24 lg:py-32 flex flex-col justify-end">
        <div className="max-w-[900px]">
          <h1 className="font-['Outfit'] text-6xl md:text-7xl lg:text-8xl leading-[0.95] text-white mb-8 tracking-tight">
            FOOTFALL LIMITED
          </h1>
          <div className="h-1 w-24 bg-gradient-to-r from-[#6EC1E4] to-[#A9DFF7] mb-10"></div>
          <p className="font-['Inter'] text-2xl md:text-3xl text-[#A9DFF7] mb-12 leading-relaxed">
            Trade Marketing. Field Operations. Retail Analytics.
          </p>
          <p className="font-['Inter'] text-xl text-white">
            hello@footfall.services
          </p>
        </div>
      </div>
    </div>
  );
}