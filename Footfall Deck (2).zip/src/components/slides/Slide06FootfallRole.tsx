export function Slide06FootfallRole() {
  return (
    <div className="w-full aspect-[16/9] bg-white relative overflow-hidden">
      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px]">
        <div className="grid grid-cols-12 gap-[24px] h-full">
          
          {/* Left - Headline */}
          <div className="col-span-5 flex flex-col justify-center">
            <h2 className="font-['Outfit'] text-[72px] leading-[1.05] text-[#2F2F2F] mb-6">
              We do
              <br />
              <span className="text-[#6EC1E4]">the work.</span>
            </h2>
          </div>

          {/* Right - Description */}
          <div className="col-span-6 col-start-7 flex flex-col justify-center">
            <p className="font-['Inter'] text-[20px] text-[#4A5C6A] leading-relaxed mb-10">
              Footfall is the operations layer that keeps your trade marketing alive across any environment:
            </p>

            <div className="space-y-3 mb-12">
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                In-field activations
              </p>
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                Trade-space merchandising
              </p>
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                Sampling programs
              </p>
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                Coverage mapping
              </p>
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                Field team management
              </p>
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                Reporting and verification
              </p>
              <p className="font-['Inter'] text-[18px] text-[#2F2F2F]">
                Issue resolution
              </p>
            </div>

            <div className="border-l-4 border-[#6EC1E4] pl-6">
              <p className="font-['Outfit'] text-[28px] text-[#2F2F2F] leading-tight">
                Execution, not guesswork.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
