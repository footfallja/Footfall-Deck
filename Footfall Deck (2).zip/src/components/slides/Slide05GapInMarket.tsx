export function Slide05GapInMarket() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Subtle geometric accent */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] border border-[#6EC1E4] opacity-10 rounded-full translate-x-1/2 -translate-y-1/2"></div>

      {/* Content - Asymmetric */}
      <div className="relative h-full flex items-center px-[120px]">
        <div className="grid grid-cols-12 gap-[24px] w-full">
          <div className="col-span-6">
            <h2 className="font-['Outfit'] text-[56px] leading-[1.1] text-white mb-12">
              Between strategy and results
              <br />
              <span className="text-[#6EC1E4]">there is the trade space.</span>
            </h2>
          </div>

          <div className="col-span-1"></div>

          <div className="col-span-4">
            <p className="font-['Inter'] text-[16px] text-[#A9DFF7] mb-8">
              Where:
            </p>

            <div className="space-y-5">
              <p className="font-['Inter'] text-[18px] text-white">
                consumers decide
              </p>
              <p className="font-['Inter'] text-[18px] text-white">
                partners improvise
              </p>
              <p className="font-['Inter'] text-[18px] text-white">
                activations succeed or fail
              </p>
              <p className="font-['Inter'] text-[18px] text-white">
                data disappears
              </p>
              <p className="font-['Inter'] text-[18px] text-white">
                real influence happens
              </p>
            </div>

            <div className="mt-12 pt-8 border-t border-[#6EC1E4]/30">
              <p className="font-['Outfit'] text-[24px] text-white leading-tight mb-2">
                Today, no one truly owns this space.
              </p>
              <p className="font-['Outfit'] text-[24px] text-[#6EC1E4] leading-tight">
                Except Footfall.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
