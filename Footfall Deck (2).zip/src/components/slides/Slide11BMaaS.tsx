export function Slide11BMaaS() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Gradient accent */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#6EC1E4]/10 to-transparent"></div>

      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px] flex items-center">
        <div className="w-full">
          
          {/* Hero Headline */}
          <div className="mb-16">
            <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-6">
              INTRODUCING
            </p>
            <h2 className="font-['Outfit'] text-[80px] leading-[1.05] text-white mb-4">
              BMaaS
            </h2>
            <p className="font-['Outfit'] text-[32px] text-[#A9DFF7] leading-tight">
              Brand Manager as a Service
            </p>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-12 gap-[24px]">
            
            {/* Left Column */}
            <div className="col-span-5">
              <p className="font-['Inter'] text-[20px] text-white leading-relaxed mb-6">
                Execution fails when no one owns it.
              </p>
              <p className="font-['Inter'] text-[20px] text-[#A9DFF7] leading-relaxed">
                BMaaS puts someone in the field who does.
              </p>
            </div>

            {/* Right Column */}
            <div className="col-span-6 col-start-7">
              <div className="space-y-8">
                <div className="border-l-4 border-[#6EC1E4] pl-6">
                  <p className="font-['Outfit'] text-[28px] text-white leading-tight">
                    You lead the brand.
                    <br />
                    We make the work happen.
                  </p>
                </div>

                <div className="bg-white/5 border border-[#6EC1E4]/30 rounded-lg p-6">
                  <p className="font-['Inter'] text-[16px] text-[#A9DFF7] leading-relaxed">
                    Pulse360 will soon give you a real-time window into every shift, in every space.
                  </p>
                </div>

                <div className="pt-6">
                  <p className="font-['Outfit'] text-[32px] text-[#6EC1E4] leading-tight">
                    BMaaS isn't oversight.
                    <br />
                    It's control.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
