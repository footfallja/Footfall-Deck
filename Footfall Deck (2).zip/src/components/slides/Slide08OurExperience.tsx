export function Slide08OurExperience() {
  return (
    <div className="w-full aspect-[16/9] bg-white relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src="https://images.unsplash.com/photo-1612703738893-31b58c0aebd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwd29yayUyMGZpZWxkfGVufDF8fHx8MTc2NTQyODQ4M3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Field teams at work"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative h-full px-[120px] py-[80px]">
        <div className="max-w-[900px]">
          <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-8">
            OUR EXPERIENCE
          </p>

          <h2 className="font-['Outfit'] text-[48px] leading-[1.15] text-[#2F2F2F] mb-10">
            Our team has years of operational experience across Jamaica's trade landscape.
          </h2>

          <p className="font-['Inter'] text-[20px] text-[#4A5C6A] mb-8">
            We have:
          </p>

          <div className="grid grid-cols-2 gap-x-12 gap-y-5 mb-12">
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Executed high-pressure event operations</span>
            </p>
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Managed multi-day field activations</span>
            </p>
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Delivered national sampling programs</span>
            </p>
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Directed merchandising across trade spaces</span>
            </p>
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Run mobile and logistics-heavy programs</span>
            </p>
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Supervised large, rotating field teams</span>
            </p>
            <p className="font-['Inter'] text-[18px] text-[#2F2F2F] flex items-start col-span-2">
              <span className="text-[#6EC1E4] mr-3">•</span>
              <span>Solved issues in real time under changing conditions</span>
            </p>
          </div>

          <div className="border-l-4 border-[#6EC1E4] pl-6">
            <p className="font-['Outfit'] text-[28px] text-[#2F2F2F] leading-tight mb-3">
              We've done the work —
            </p>
            <p className="font-['Inter'] text-[18px] text-[#4A5C6A] mb-4">
              the systems, the pressure, the unpredictability.
            </p>
            <p className="font-['Outfit'] text-[28px] text-[#6EC1E4] leading-tight">
              Footfall is built on that experience.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
