export function Slide08CaseStudyCarnival() {
  const metrics = [
    { value: '25', label: 'Store Activations', unit: '' },
    { value: '7,500+', label: 'Consumer Interactions', unit: '' },
    { value: '3,200+', label: 'Product Samples', unit: '' }
  ];

  return (
    <div className="w-full h-full min-h-[600px] lg:min-h-[700px] bg-white relative overflow-hidden">
      
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=1920&auto=format&q=75"
          alt="Carnival celebration atmosphere"
          className="w-full h-full object-cover opacity-15"
          loading="lazy"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/90 to-white/70"></div>
      </div>

      <div className="relative h-full flex flex-col justify-end px-8 md:px-16 lg:px-24 xl:px-32 py-16 lg:py-20">
        
        {/* Case Study Label */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-3 bg-[#6EC1E4] text-white px-4 py-2 rounded-full">
            <span className="font-['Inter'] text-xs uppercase tracking-wider">Case Study 01</span>
          </div>
        </div>

        {/* Title */}
        <h2 className="font-['Outfit'] text-[40px] md:text-[52px] lg:text-[64px] leading-[1.05] text-[#2F2F2F] tracking-tight mb-6">
          STR8 VYBZ<br />Carnival 2024
        </h2>

        {/* Description */}
        <p className="font-['Inter'] text-lg md:text-xl text-[#4A5C6A] leading-relaxed mb-12 max-w-[700px]">
          Island-wide activation across Kingston, Montego Bay, and Ocho Rios during Jamaica's peak carnival season.
        </p>

        {/* Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 lg:gap-12 max-w-[900px]">
          {metrics.map((metric, index) => (
            <div key={index} className="group">
              <div className="mb-2">
                <span className="font-['Outfit'] text-[48px] md:text-[56px] leading-none text-[#6EC1E4] block">
                  {metric.value}
                </span>
              </div>
              <div className="font-['Inter'] text-sm md:text-base text-[#2F2F2F] uppercase tracking-wide">
                {metric.label}
              </div>
              <div className="w-0 group-hover:w-full h-0.5 bg-[#6EC1E4] transition-all duration-500 mt-3"></div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
