export function Slide01Cover() {
  return (
    <div className="w-full aspect-[16/9] bg-[#2F2F2F] relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1734076459124-308d638c5d92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxKYW1haWNhbiUyMHN1cGVybWFya2V0JTIwYWlzbGV8ZW58MXx8fHwxNzY1NDI4NDgxfDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Jamaican trade environment"
          className="w-full h-full object-cover"
        />
        {/* Sky Blue 40% Overlay */}
        <div className="absolute inset-0 bg-[#6EC1E4] opacity-40"></div>
        {/* Additional dark overlay for contrast */}
        <div className="absolute inset-0 bg-[#2F2F2F] opacity-30"></div>
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-end px-[120px] pb-[100px]">
        <div className="max-w-[800px]">
          <h1 className="font-['Outfit'] text-[72px] leading-[1.05] tracking-tight text-white mb-6">
            FOOTFALL LIMITED
          </h1>
          <p className="font-['Inter'] text-[24px] text-[#A9DFF7] mb-12 leading-relaxed">
            Trade Marketing. Field Operations. Retail Analytics.
          </p>
          <p className="font-['Inter'] text-[18px] text-white">
            hello@footfall.services
          </p>
        </div>
      </div>
    </div>
  );
}
