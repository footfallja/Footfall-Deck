import { useState } from 'react';

export function Slide07Sampling() {
  const [layoutOption, setLayoutOption] = useState<1 | 2>(1);

  return (
    <div className="w-full h-full min-h-[600px] bg-white flex flex-col lg:flex-row">
      {/* Left Content - 50% */}
      <div className="w-full lg:w-[50%] px-8 md:px-16 lg:px-20 py-12 md:py-16 lg:py-20 flex flex-col justify-center">
        <div className="mb-6">
          <div className="text-sm font-['Inter'] text-[#6EC1E4] mb-2">CASE STUDY</div>
          <h2 className="font-['Outfit'] text-4xl md:text-5xl leading-[0.95] text-[#2F2F2F] mb-3">
            Standalone<br />Executions
          </h2>
          <p className="font-['Inter'] text-lg text-[#4A5C6A]">
            Consistent Shopper Engagement • Multi-Store Coverage
          </p>
        </div>

        <div className="space-y-6 mb-8">
          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Owned</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Sampling • Shopper interaction • Team mgmt • Content capture • Data Collection
            </p>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Reality</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Real shoppers • Real stores • Peak traffic flow • Stock movement • Retail coordination
            </p>
          </div>

          <div>
            <h4 className="font-['Outfit'] text-lg text-[#2F2F2F] mb-2">Delivered</h4>
            <p className="font-['Inter'] text-base text-[#4A5C6A] leading-relaxed">
              Clean setups • Disciplined sampling • Accurate reporting • Verified execution • Brand visibility that lasts
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-[#6EC1E4] flex items-center justify-between">
          <p className="font-['Outfit'] text-xl text-[#2F2F2F]">
            Core Strength: <span className="text-[#6EC1E4]">Retail consistency.</span>
          </p>
          
          {/* Layout Toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => setLayoutOption(1)}
              className={`px-3 py-1.5 text-xs rounded transition-all ${
                layoutOption === 1 
                  ? 'bg-[#6EC1E4] text-white' 
                  : 'bg-gray-200 text-[#4A5C6A] hover:bg-gray-300'
              }`}
            >
              2 Horizontal
            </button>
            <button
              onClick={() => setLayoutOption(2)}
              className={`px-3 py-1.5 text-xs rounded transition-all ${
                layoutOption === 2 
                  ? 'bg-[#6EC1E4] text-white' 
                  : 'bg-gray-200 text-[#4A5C6A] hover:bg-gray-300'
              }`}
            >
              Mixed
            </button>
          </div>
        </div>
      </div>

      {/* Right Images - 50% */}
      <div className="w-full lg:w-[50%] h-[300px] lg:h-full relative">
        {layoutOption === 1 ? (
          // Option 1: 2 horizontal blocks stacked
          <div className="w-full h-full flex flex-col">
            <div className="w-full h-1/2 relative">
              <img
                src="https://images.unsplash.com/photo-1512106374988-c95f566d39ef?w=1200&auto=format&q=75"
                alt="Supermarket shopping"
                className="w-full h-full object-cover"
                loading="eager"
                decoding="async"
              />
            </div>
            <div className="w-full h-1/2 relative">
              <img
                src="https://images.unsplash.com/photo-1722319493299-7397c34ee511?w=1200&auto=format&q=75"
                alt="Retail product display"
                className="w-full h-full object-cover"
                loading="eager"
                decoding="async"
              />
            </div>
          </div>
        ) : (
          // Option 2: 1 horizontal and 1 vertical side-by-side
          <div className="w-full h-full flex">
            <div className="w-2/3 h-full relative">
              <img
                src="https://images.unsplash.com/photo-1512106374988-c95f566d39ef?w=1200&auto=format&q=75"
                alt="Supermarket shopping"
                className="w-full h-full object-cover"
                loading="eager"
                decoding="async"
              />
            </div>
            <div className="w-1/3 h-full relative">
              <img
                src="https://images.unsplash.com/photo-1722319493299-7397c34ee511?w=1200&auto=format&q=75"
                alt="Retail product display"
                className="w-full h-full object-cover"
                loading="eager"
                decoding="async"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}