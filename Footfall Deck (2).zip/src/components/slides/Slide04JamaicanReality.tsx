export function Slide04JamaicanReality() {
  return (
    <div className="w-full aspect-[16/9] bg-white relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://images.unsplash.com/photo-1639448158266-80694db01f2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxKYW1haWNhbiUyMG1hcmtldCUyMHN0cmVldHxlbnwxfHx8fDE3NjU0Mjg0ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Jamaican trade environments"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative h-full grid grid-cols-12 gap-[24px] px-[120px] py-[80px]">
        <div className="col-span-7">
          <p className="font-['Inter'] text-[12px] uppercase tracking-widest text-[#6EC1E4] mb-6">
            THE JAMAICAN TRADE REALITY
          </p>
          
          <h2 className="font-['Outfit'] text-[48px] leading-[1.15] text-[#2F2F2F] mb-10">
            Jamaica's trade environment is uneven and unpredictable.
          </h2>

          <p className="font-['Inter'] text-[20px] text-[#4A5C6A] leading-relaxed mb-8">
            A significant share of consumption moves through informal and semi-formal spaces, shaped by different behaviours, income levels, and expectations.
          </p>

          <div className="space-y-4 mb-10">
            <p className="font-['Inter'] text-[20px] text-[#2F2F2F]">
              Standards fluctuate.
            </p>
            <p className="font-['Inter'] text-[20px] text-[#2F2F2F]">
              Consumer decisions shift.
            </p>
            <p className="font-['Inter'] text-[20px] text-[#2F2F2F]">
              Conditions change without warning.
            </p>
          </div>

          <p className="font-['Outfit'] text-[24px] leading-snug text-[#2F2F2F] border-l-4 border-[#6EC1E4] pl-6">
            Effective trade execution must absorb this variability, not wait for perfect conditions.
          </p>

          <p className="font-['Inter'] text-[14px] text-[#4A5C6A] italic mt-8">
            Source: Jamaican consumer & trade environment reporting.
          </p>
        </div>
      </div>
    </div>
  );
}
